import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { 
  MapPin, 
  Navigation, 
  Search, 
  Filter,
  Loader2,
  Target,
  TrendingUp,
  Clock,
  Users,
  DollarSign
} from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Mission {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  reward: number;
  participants: number;
  maxParticipants: number;
  timeEstimate: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  distance?: string;
  isUrgent?: boolean;
}

interface NearbyMissionsFinderProps {
  currentLocation?: { lat: number; lng: number; };
  maxDistance?: number; // km
}

export function NearbyMissionsFinder({ currentLocation, maxDistance = 5 }: NearbyMissionsFinderProps) {
  const [missions, setMissions] = useState<Mission[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchRadius, setSearchRadius] = useState(maxDistance);
  const [location, setLocation] = useState(currentLocation);
  const [addressQuery, setAddressQuery] = useState('');

  useEffect(() => {
    if (location) {
      loadNearbyMissions();
    }
  }, [location, searchRadius]);

  const getCurrentLocation = () => {
    setLoading(true);
    
    if (!navigator.geolocation) {
      alert('La geolocalización no está disponible en tu navegador');
      // Fallback a Yumbo
      setLocation({ lat: 3.5836, lng: -76.4951 });
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
        setLoading(false);
      },
      (error) => {
        let errorMsg = 'No se pudo obtener la ubicación';
        let detailedMsg = '';
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMsg = '📍 Permiso de ubicación denegado';
            detailedMsg = 'Por favor permite el acceso a tu ubicación en la configuración del navegador. Haz clic en el ícono de candado junto a la URL.';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMsg = '🛰️ Señal GPS no disponible';
            detailedMsg = 'Asegúrate de estar en un lugar con buena visibilidad al cielo si es posible.';
            break;
          case error.TIMEOUT:
            errorMsg = '⏱️ Tiempo de espera agotado';
            detailedMsg = 'El GPS está tardando demasiado. Verifica tu conexión e intenta nuevamente.';
            break;
          default:
            errorMsg = '⚠️ Error de geolocalización';
            detailedMsg = error.message || 'Error desconocido al obtener tu ubicación.';
        }
        
        console.log('🔍 NearbyMissionsFinder - Geolocation error:', {
          errorCode: error.code,
          errorType: error.code === 1 ? 'PERMISSION_DENIED' : error.code === 2 ? 'POSITION_UNAVAILABLE' : error.code === 3 ? 'TIMEOUT' : 'UNKNOWN',
          originalMessage: error.message,
          userMessage: errorMsg,
          detailedMessage: detailedMsg,
          fallbackLocation: 'Yumbo (3.5836, -76.4951)',
          timestamp: new Date().toISOString()
        });
        
        alert(`${errorMsg}\n\n${detailedMsg}\n\nUsando ubicación predeterminada de Yumbo, Valle del Cauca.`);
        
        // Fallback a Yumbo
        setLocation({ lat: 3.5836, lng: -76.4951 });
        setLoading(false);
      },
      {
        enableHighAccuracy: false, // Cambiar a false para mejor compatibilidad
        timeout: 15000,
        maximumAge: 30000
      }
    );
  };

  const loadNearbyMissions = async () => {
    if (!location) return;
    
    setLoading(true);
    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-34f10c60/missions`;
      const params = new URLSearchParams({
        lat: location.lat.toString(),
        lng: location.lng.toString(),
        radius: searchRadius.toString()
      });

      const response = await fetch(`${url}?${params.toString()}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && data.missions) {
          setMissions(data.missions);
        }
      }
    } catch (error) {
      console.error('Error loading nearby missions:', error);
    }
    setLoading(false);
  };

  const searchByAddress = async () => {
    if (!addressQuery.trim()) return;
    
    setLoading(true);
    try {
      // Geocodificar la dirección usando Nominatim
      const geocodeUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(addressQuery + ', Yumbo, Colombia')}&limit=1`;
      
      const response = await fetch(geocodeUrl, {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'GoodImpact-App'
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.length > 0) {
          const { lat, lon } = data[0];
          setLocation({
            lat: parseFloat(lat),
            lng: parseFloat(lon)
          });
        } else {
          alert('No se encontró la dirección. Intenta con otra dirección en Yumbo.');
        }
      }
    } catch (error) {
      console.error('Error geocoding address:', error);
      alert('Error al buscar la dirección');
    }
    setLoading(false);
  };

  return (
    <div className="w-full space-y-4">
      {/* Controles de búsqueda */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Target className="w-5 h-5 mr-2 text-blue-600" />
            Encuentra Misiones Cerca de Ti
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Búsqueda por GPS */}
          <div className="flex space-x-2">
            <Button 
              onClick={getCurrentLocation}
              disabled={loading}
              className="flex-1"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Obteniendo ubicación...
                </>
              ) : (
                <>
                  <Navigation className="w-4 h-4 mr-2" />
                  Usar mi ubicación GPS
                </>
              )}
            </Button>
          </div>

          {/* Búsqueda por dirección */}
          <div className="flex space-x-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                value={addressQuery}
                onChange={(e) => setAddressQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && searchByAddress()}
                placeholder="O escribe una dirección en Yumbo..."
                className="pl-10"
              />
            </div>
            <Button onClick={searchByAddress} disabled={loading || !addressQuery.trim()}>
              Buscar
            </Button>
          </div>

          {/* Control de radio de búsqueda */}
          {location && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Radio de búsqueda: {searchRadius} km</label>
              <input
                type="range"
                min="1"
                max="25"
                step="1"
                value={searchRadius}
                onChange={(e) => setSearchRadius(parseInt(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>1 km</span>
                <span>25 km</span>
              </div>
            </div>
          )}

          {/* Información de ubicación actual */}
          {location && (
            <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-blue-600" />
                <div className="text-sm">
                  <span className="font-medium text-blue-900">Buscando desde:</span>
                  <span className="text-blue-700 ml-2">
                    {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                  </span>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Resultados */}
      {loading ? (
        <Card>
          <CardContent className="p-12 text-center">
            <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
            <p className="text-gray-600">Buscando misiones cercanas...</p>
          </CardContent>
        </Card>
      ) : missions.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MapPin className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="font-bold text-gray-900 mb-2">No hay misiones cercanas</h3>
            <p className="text-gray-600 mb-4">
              No se encontraron misiones dentro de {searchRadius} km de tu ubicación
            </p>
            <Button onClick={() => setSearchRadius(Math.min(searchRadius + 5, 25))}>
              Ampliar radio de búsqueda
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold">
              {missions.length} misiones encontradas
            </h3>
            <Badge variant="outline">
              Radio: {searchRadius} km
            </Badge>
          </div>

          {missions.map((mission) => (
            <Card key={mission.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-bold flex items-center">
                      {mission.title}
                      {mission.isUrgent && (
                        <Badge variant="destructive" className="ml-2 text-xs">
                          URGENTE
                        </Badge>
                      )}
                    </h4>
                    <p className="text-sm text-gray-600 line-clamp-2 mt-1">
                      {mission.description}
                    </p>
                  </div>
                  {mission.distance && (
                    <Badge className="bg-blue-100 text-blue-800 ml-2">
                      📍 {mission.distance}
                    </Badge>
                  )}
                </div>

                <div className="flex flex-wrap gap-2 mb-3">
                  <Badge variant="secondary">{mission.category}</Badge>
                  <Badge variant="outline">{mission.difficulty}</Badge>
                  <Badge variant="outline" className="text-green-600">
                    +{mission.reward} pts
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-gray-600 mb-3">
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-3 h-3" />
                    <span className="truncate">{mission.location.address}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{mission.timeEstimate}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="w-3 h-3" />
                    <span>{mission.participants}/{mission.maxParticipants} personas</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <DollarSign className="w-3 h-3" />
                    <span>{mission.reward} puntos</span>
                  </div>
                </div>

                <Button size="sm" className="w-full">
                  Ver Detalles y Unirse
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
