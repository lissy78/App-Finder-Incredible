import { useState, useEffect } from 'react';
import { Alert, AlertDescription } from './ui/alert';
import { MapPin, AlertCircle, CheckCircle } from 'lucide-react';

interface GeolocationStatusProps {
  onLocationDetected?: (location: { lat: number; lng: number; address: string }) => void;
}

export function GeolocationStatus({ onLocationDetected }: GeolocationStatusProps) {
  const [status, setStatus] = useState<'checking' | 'allowed' | 'denied' | 'unavailable' | 'error'>('checking');
  const [message, setMessage] = useState('Verificando permisos de ubicación...');

  useEffect(() => {
    checkGeolocationStatus();
  }, []);

  const checkGeolocationStatus = async () => {
    if (!navigator.geolocation) {
      setStatus('unavailable');
      setMessage('La geolocalización no está disponible en tu navegador. Usando ubicación de Yumbo por defecto.');
      return;
    }

    try {
      // Verificar permisos de geolocalización
      if ('permissions' in navigator) {
        const permission = await navigator.permissions.query({ name: 'geolocation' });
        
        switch (permission.state) {
          case 'granted':
            setStatus('allowed');
            setMessage('Ubicación permitida. Detectando tu posición...');
            getCurrentLocation();
            break;
          case 'denied':
            setStatus('denied');
            setMessage('Permisos de ubicación denegados. Usando ubicación de Yumbo por defecto.');
            useFallbackLocation();
            break;
          case 'prompt':
            setStatus('checking');
            setMessage('Se solicitarán permisos de ubicación...');
            getCurrentLocation();
            break;
        }
      } else {
        // Fallback para navegadores que no soportan permissions API
        getCurrentLocation();
      }
    } catch (error) {
      console.error('Error checking geolocation permissions:', error);
      setStatus('error');
      setMessage('Error verificando permisos. Usando ubicación de Yumbo por defecto.');
      useFallbackLocation();
    }
  };

  const getCurrentLocation = () => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setStatus('allowed');
        setMessage('Ubicación detectada correctamente.');
        
        if (onLocationDetected) {
          onLocationDetected({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            address: `Ubicación actual (${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)})`
          });
        }
      },
      (error) => {
        let errorMessage = 'Error obteniendo ubicación';
        
        switch (error.code) {
          case 1: // PERMISSION_DENIED
            setStatus('denied');
            errorMessage = '📍 Permisos de ubicación denegados. Haz clic en el ícono de candado en la barra de direcciones para permitir la ubicación. Mientras tanto, estamos usando Yumbo como ubicación predeterminada.';
            break;
          case 2: // POSITION_UNAVAILABLE
            setStatus('error');
            errorMessage = '📍 Tu ubicación GPS no está disponible en este momento. Verifica tu conexión y asegúrate de estar al aire libre si es necesario. Usando Yumbo como ubicación predeterminada.';
            break;
          case 3: // TIMEOUT
            setStatus('error');
            errorMessage = '⏱️ El GPS está tardando demasiado en responder. Verifica tu señal y vuelve a intentar. Usando Yumbo como ubicación predeterminada.';
            break;
          default:
            setStatus('error');
            errorMessage = `⚠️ Error de geolocalización: ${error.message || 'Desconocido'}. Usando Yumbo como ubicación predeterminada.`;
        }
        
        console.log('📍 Geolocation error detected:', {
          errorCode: error.code,
          errorType: error.code === 1 ? 'PERMISSION_DENIED' : error.code === 2 ? 'POSITION_UNAVAILABLE' : error.code === 3 ? 'TIMEOUT' : 'UNKNOWN',
          originalMessage: error.message,
          userFriendlyMessage: errorMessage,
          timestamp: new Date().toISOString()
        });
        
        setMessage(errorMessage);
        useFallbackLocation();
      },
      {
        enableHighAccuracy: false,
        timeout: 15000,
        maximumAge: 60000
      }
    );
  };

  const useFallbackLocation = () => {
    if (onLocationDetected) {
      onLocationDetected({
        lat: 3.5836,
        lng: -76.4951,
        address: 'Yumbo, Valle del Cauca, Colombia'
      });
    }
  };

  const getIcon = () => {
    switch (status) {
      case 'allowed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'denied':
      case 'error':
      case 'unavailable':
        return <AlertCircle className="w-4 h-4 text-orange-600" />;
      default:
        return <MapPin className="w-4 h-4 text-blue-600" />;
    }
  };

  const getVariant = () => {
    switch (status) {
      case 'allowed':
        return 'default'; // Success-like appearance
      case 'denied':
      case 'error':
      case 'unavailable':
        return 'destructive';
      default:
        return 'default';
    }
  };

  // Solo mostrar la alerta si hay un mensaje importante para el usuario
  if (status === 'allowed') {
    return (
      <Alert className="mb-4 bg-green-50 border-green-200">
        <CheckCircle className="w-4 h-4 text-green-600" />
        <AlertDescription className="text-green-800">
          ✅ {message}
        </AlertDescription>
      </Alert>
    );
  }

  if (status === 'checking') {
    return null; // No mostrar mientras se está verificando
  }

  return (
    <Alert 
      className={`mb-4 ${
        status === 'denied' || status === 'error' 
          ? 'bg-yellow-50 border-yellow-200' 
          : 'bg-blue-50 border-blue-200'
      }`}
    >
      <div className="flex items-start space-x-2">
        {getIcon()}
        <AlertDescription className={`flex-1 ${
          status === 'denied' || status === 'error' 
            ? 'text-yellow-900' 
            : 'text-blue-900'
        }`}>
          {message}
        </AlertDescription>
      </div>
    </Alert>
  );
}