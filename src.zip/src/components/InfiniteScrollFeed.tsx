import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Heart, MessageCircle, Share2, MapPin, Star } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Post {
  id: string;
  author: {
    name: string;
    avatar: string;
    goodnessLevel: number;
    location: string;
  };
  content: string;
  image?: string;
  type: 'mission' | 'achievement' | 'story';
  likes: number;
  comments: number;
  timestamp: string;
  missionReward?: number;
}

// Generador de IDs únicos
let postIdCounter = 0;

const generateMockPosts = (start: number, count: number): Post[] => {
  const missions = [
    'Plantar 100 árboles en el parque central',
    'Limpiar la playa durante el fin de semana',
    'Enseñar programación a niños sin recursos',
    'Desarrollar app para reciclaje comunitario',
    'Organizar mercado de productos locales',
    'Crear campaña de concienciación ambiental',
    'Diseñar sistema de huerto urbano',
    'Coordinar donación de alimentos'
  ];

  const achievements = [
    'Completó 50 misiones de sostenibilidad',
    'Ayudó a 200 familias este mes',
    'Redujo huella de carbono en 30%',
    'Lideró proyecto de energía solar',
    'Creó comunidad de 1000 miembros'
  ];

  const authors = [
    { name: 'Elena Verde', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b169', location: 'Madrid, España' },
    { name: 'Carlos Eco', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d', location: 'Buenos Aires, Argentina' },
    { name: 'Sofia Impact', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80', location: 'México DF, México' },
    { name: 'Miguel Green', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e', location: 'Yumbo, Valle del Cauca' }
  ];

  return Array.from({ length: count }, (_, i) => {
    const index = start + i;
    const author = authors[index % authors.length];
    const isMission = index % 3 === 0;
    const isAchievement = index % 4 === 0;
    
    // Generar ID único usando contador global
    postIdCounter++;
    const uniqueId = `post-${postIdCounter}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    
    return {
      id: uniqueId,
      author: {
        ...author,
        goodnessLevel: Math.floor(Math.random() * 100) + 1
      },
      content: isMission 
        ? missions[index % missions.length]
        : isAchievement 
        ? achievements[index % achievements.length]
        : 'Compartiendo mi experiencia en esta misión increíble. Cada pequeña acción cuenta para crear un mundo mejor. ¡Únete a nosotros!',
      image: index % 2 === 0 ? 'https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4' : undefined,
      type: isMission ? 'mission' : isAchievement ? 'achievement' : 'story',
      likes: Math.floor(Math.random() * 500) + 10,
      comments: Math.floor(Math.random() * 50) + 1,
      timestamp: `${Math.floor(Math.random() * 24)}h`,
      missionReward: isMission ? Math.floor(Math.random() * 500) + 100 : undefined
    };
  });
};

export function InfiniteScrollFeed() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  const loadPosts = useCallback(async () => {
    if (loading || !hasMore) return;
    
    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-34f10c60/feed?page=${page}&limit=10`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.posts && data.posts.length > 0) {
          setPosts(prev => {
            const existingIds = new Set(prev.map(p => p.id));
            const newPosts = data.posts.filter((p: Post) => !existingIds.has(p.id));
            return [...prev, ...newPosts];
          });
          setPage(prev => prev + 1);
          if (data.posts.length < 10) {
            setHasMore(false);
          }
        } else {
          // Fallback a datos mock
          const newPosts = generateMockPosts(page * 10, 10);
          setPosts(prev => {
            const existingIds = new Set(prev.map(p => p.id));
            const filteredNewPosts = newPosts.filter(p => !existingIds.has(p.id));
            return [...prev, ...filteredNewPosts];
          });
          setPage(prev => prev + 1);
        }
      } else {
        throw new Error('Network response was not ok');
      }
    } catch (error) {
      console.error('Error loading posts:', error);
      // Fallback a datos mock
      const newPosts = generateMockPosts(page * 10, 10);
      setPosts(prev => {
        const existingIds = new Set(prev.map(p => p.id));
        const filteredNewPosts = newPosts.filter(p => !existingIds.has(p.id));
        return [...prev, ...filteredNewPosts];
      });
      setPage(prev => prev + 1);
    }
    setLoading(false);
  }, [page, loading, hasMore]);

  useEffect(() => {
    if (posts.length === 0) {
      loadPosts();
    }
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (window.innerHeight + document.documentElement.scrollTop >= document.documentElement.offsetHeight - 1000) {
        if (!loading && hasMore) {
          loadPosts();
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [loading, hasMore, loadPosts]);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'mission': return 'bg-blue-100 text-blue-800';
      case 'achievement': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'mission': return 'Misión';
      case 'achievement': return 'Logro';
      default: return 'Historia';
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {posts.map((post) => (
        <Card key={post.id} className="w-full">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Avatar>
                  <AvatarImage src={post.author.avatar} />
                  <AvatarFallback>{post.author.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center space-x-2">
                    <p className="font-medium">{post.author.name}</p>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="text-sm text-yellow-600">{post.author.goodnessLevel}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                    <MapPin className="w-3 h-3" />
                    <span>{post.author.location}</span>
                    <span>•</span>
                    <span>{post.timestamp}</span>
                  </div>
                </div>
              </div>
              <Badge className={getTypeColor(post.type)}>
                {getTypeLabel(post.type)}
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent className="pt-0">
            <p className="mb-4">{post.content}</p>
            
            {post.missionReward && (
              <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-blue-700">Recompensa por misión:</span>
                  <span className="font-medium text-blue-800">{post.missionReward} puntos de bondad</span>
                </div>
              </div>
            )}
            
            {post.image && (
              <div className="mb-4">
                <ImageWithFallback 
                  src={post.image} 
                  alt="Post image"
                  className="w-full h-64 object-cover rounded-lg"
                />
              </div>
            )}
            
            <div className="flex items-center justify-between pt-4 border-t">
              <div className="flex items-center space-x-4">
                <Button variant="ghost" size="sm" className="flex items-center space-x-2">
                  <Heart className="w-4 h-4" />
                  <span>{post.likes}</span>
                </Button>
                <Button variant="ghost" size="sm" className="flex items-center space-x-2">
                  <MessageCircle className="w-4 h-4" />
                  <span>{post.comments}</span>
                </Button>
              </div>
              <Button variant="ghost" size="sm">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
      
      {loading && (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      )}
    </div>
  );
}