import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MapPin, Navigation, Users, Clock, DollarSign, Zap, Target } from 'lucide-react';
import { LocationSearch } from './LocationSearch';

interface Mission {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  reward: number;
  participants: number;
  maxParticipants: number;
  timeEstimate: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  isUrgent?: boolean;
}

interface GeoEnhancedMapProps {
  missions: Mission[];
  selectedMission: Mission | null;
  onMissionSelect: (mission: Mission | null) => void;
  userLocation?: { lat: number; lng: number } | null;
}

export function GeoEnhancedMap({ 
  missions, 
  selectedMission, 
  onMissionSelect,
  userLocation 
}: GeoEnhancedMapProps) {
  const [searchLocation, setSearchLocation] = useState<{lat: number, lng: number} | null>(null);
  const [mapCenter, setMapCenter] = useState({ lat: 3.5836, lng: -76.4951 }); // Centro de Yumbo
  const [zoomLevel, setZoomLevel] = useState(1);

  // Calcular distancia entre dos puntos (en km)
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
    const R = 6371; // Radio de la Tierra en km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  // Obtener posición en el mapa basada en coordenadas reales
  const getMapPosition = (lat: number, lng: number) => {
    const centerLat = mapCenter.lat;
    const centerLng = mapCenter.lng;
    
    // Rango de visualización (aproximadamente 0.05 grados = ~5.5 km)
    const latRange = 0.05 * zoomLevel;
    const lngRange = 0.05 * zoomLevel;
    
    // Convertir coordenadas reales a porcentajes del mapa
    const latPercent = 50 - ((lat - centerLat) / latRange) * 40; // 40% del rango visible
    const lngPercent = 50 + ((lng - centerLng) / lngRange) * 40;
    
    return {
      top: Math.max(5, Math.min(95, latPercent)),
      left: Math.max(5, Math.min(95, lngPercent))
    };
  };

  // Categorías con colores y íconos
  const categoryInfo = {
    'Medio Ambiente': { color: 'bg-green-500', icon: '🌱' },
    'Tecnología': { color: 'bg-blue-500', icon: '💻' },
    'Educación': { color: 'bg-purple-500', icon: '📚' },
    'Agricultura': { color: 'bg-orange-500', icon: '🌾' },
    'Arte': { color: 'bg-pink-500', icon: '🎨' },
    'Deportes': { color: 'bg-red-500', icon: '⚽' },
    'Cocina': { color: 'bg-yellow-500', icon: '👨‍🍳' },
    'Música': { color: 'bg-indigo-500', icon: '🎵' }
  };

  const handleLocationSearch = (location: {lat: number, lng: number, address: string}) => {
    setSearchLocation({lat: location.lat, lng: location.lng});
    setMapCenter({lat: location.lat, lng: location.lng});
  };

  const centerOnYumbo = () => {
    setMapCenter({ lat: 3.5836, lng: -76.4951 });
    setSearchLocation(null);
  };

  const centerOnUser = () => {
    if (userLocation) {
      setMapCenter(userLocation);
      setSearchLocation(userLocation);
    }
  };

  return (
    <Card className="h-96 lg:h-[600px] border-2 border-blue-200 shadow-xl">
      <CardHeader className="pb-3">
        <div className="flex flex-col space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-blue-600" />
              <h3 className="font-semibold">Mapa de Misiones en Tiempo Real</h3>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="text-green-600 border-green-600">
                🟢 {missions.length} activas
              </Badge>
              <Badge variant="outline" className="text-blue-600 border-blue-600">
                📍 Yumbo, Valle
              </Badge>
            </div>
          </div>
          
          {/* Controles de búsqueda y navegación */}
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
            <div className="flex-1">
              <LocationSearch
                onLocationSelect={handleLocationSearch}
                placeholder="Buscar ubicación en el mapa..."
                focusOnYumbo={true}
              />
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={centerOnYumbo}
                className="flex items-center space-x-1"
              >
                <MapPin className="w-4 h-4" />
                <span className="hidden sm:inline">Centro</span>
              </Button>
              {userLocation && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={centerOnUser}
                  className="flex items-center space-x-1"
                >
                  <Navigation className="w-4 h-4" />
                  <span className="hidden sm:inline">Mi ubicación</span>
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-0 relative">
        <div className="relative w-full h-full bg-gradient-to-br from-green-50 via-blue-50 to-yellow-50 rounded-lg overflow-hidden border-2 border-green-200">
          {/* Fondo del mapa */}
          <div 
            className="absolute inset-0 bg-cover bg-center opacity-30" 
            style={{ 
              backgroundImage: 'url(https://images.unsplash.com/photo-1568489711036-9c94a7d5aea6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvbWJpYSUyMHZhbGxleSUyMGxhbmRzY2FwZSUyMG1vdW50YWluc3xlbnwxfHx8fDE3NTc1MTgwMjN8MA&ixlib=rb-4.1.0&q=80&w=1080)' 
            }}
          />
          
          {/* Grid de referencia */}
          <div className="absolute inset-0 opacity-10">
            <div className="grid grid-cols-10 grid-rows-10 h-full w-full">
              {Array.from({ length: 100 }).map((_, i) => (
                <div key={i} className="border border-gray-400" />
              ))}
            </div>
          </div>
          
          {/* Overlay con patrón */}
          <div className="absolute inset-0 bg-gradient-to-r from-green-100/20 to-blue-100/20" />
          
          {/* Indicadores de misiones */}
          <div className="absolute inset-0">
            {missions.map((mission) => {
              const position = getMapPosition(mission.location.lat, mission.location.lng);
              const categoryStyle = categoryInfo[mission.category] || { color: 'bg-gray-500', icon: '📍' };
              const distance = userLocation 
                ? calculateDistance(userLocation.lat, userLocation.lng, mission.location.lat, mission.location.lng)
                : null;
              
              return (
                <div
                  key={mission.id}
                  className={`absolute w-8 h-8 ${categoryStyle.color} rounded-full border-3 border-white shadow-xl cursor-pointer transform -translate-x-1/2 -translate-y-1/2 hover:scale-125 transition-all duration-300 group z-10 ${
                    selectedMission?.id === mission.id ? 'scale-150 ring-4 ring-yellow-400 shadow-2xl' : ''
                  }`}
                  style={{
                    left: `${position.left}%`,
                    top: `${position.top}%`
                  }}
                  onClick={() => onMissionSelect(mission)}
                >
                  <div className="w-full h-full flex items-center justify-center text-white">
                    <span className="text-xs">{categoryStyle.icon}</span>
                  </div>
                  
                  {/* Indicador de urgencia */}
                  {mission.isUrgent && (
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border border-white animate-pulse" />
                  )}
                  
                  {/* Tooltip detallado */}
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-3 px-4 py-3 bg-black/95 text-white text-sm rounded-xl opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none whitespace-nowrap z-30 backdrop-blur-sm shadow-2xl">
                    <div className="space-y-2">
                      <div className="font-bold text-yellow-400">{mission.title}</div>
                      <div className="text-gray-300 text-xs">{mission.location.address}</div>
                      <div className="flex items-center space-x-4 text-xs">
                        <span className="flex items-center space-x-1">
                          <DollarSign className="w-3 h-3 text-green-400" />
                          <span>{mission.reward} pts</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Users className="w-3 h-3 text-blue-400" />
                          <span>{mission.participants}/{mission.maxParticipants}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Clock className="w-3 h-3 text-purple-400" />
                          <span>{mission.timeEstimate}</span>
                        </span>
                      </div>
                      {distance && (
                        <div className="text-xs text-gray-400">
                          📍 {distance.toFixed(1)} km de distancia
                        </div>
                      )}
                      <div className="text-xs text-green-400">Click para más detalles</div>
                    </div>
                    {/* Flecha del tooltip */}
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black/95" />
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* Indicador de usuario con animación de tiempo real */}
          {userLocation && (
            <>
              {/* Círculo de precisión */}
              <div 
                className="absolute bg-blue-200/30 rounded-full border-2 border-blue-300/50 transform -translate-x-1/2 -translate-y-1/2 z-10"
                style={{
                  left: `${getMapPosition(userLocation.lat, userLocation.lng).left}%`,
                  top: `${getMapPosition(userLocation.lat, userLocation.lng).top}%`,
                  width: '60px',
                  height: '60px'
                }}
              />
              
              {/* Indicador principal del usuario */}
              <div 
                className="absolute w-7 h-7 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full border-4 border-white shadow-2xl transform -translate-x-1/2 -translate-y-1/2 z-20"
                style={{
                  left: `${getMapPosition(userLocation.lat, userLocation.lng).left}%`,
                  top: `${getMapPosition(userLocation.lat, userLocation.lng).top}%`
                }}
                title="Tu ubicación en tiempo real"
              >
                {/* Pulso animado */}
                <div className="absolute inset-0 bg-blue-400 rounded-full animate-ping opacity-75" />
                
                {/* Centro del marcador */}
                <div className="w-full h-full flex items-center justify-center relative z-10">
                  <div className="w-3 h-3 bg-white rounded-full shadow-inner" />
                </div>
                
                {/* Badge "EN VIVO" */}
                <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-green-600 text-white text-xs px-2 py-0.5 rounded-full whitespace-nowrap font-medium shadow-lg flex items-center space-x-1">
                  <Zap className="w-3 h-3" />
                  <span>EN VIVO</span>
                </div>
              </div>
            </>
          )}
          
          {/* Indicador de búsqueda */}
          {searchLocation && (
            <div 
              className="absolute w-8 h-8 bg-red-500 rounded-full border-4 border-white shadow-xl transform -translate-x-1/2 -translate-y-1/2 z-20 animate-bounce"
              style={{
                left: `${getMapPosition(searchLocation.lat, searchLocation.lng).left}%`,
                top: `${getMapPosition(searchLocation.lat, searchLocation.lng).top}%`
              }}
              title="Ubicación buscada"
            >
              <div className="w-full h-full flex items-center justify-center">
                <MapPin className="w-4 h-4 text-white" />
              </div>
            </div>
          )}
          
          {/* Leyenda mejorada */}
          <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm rounded-xl p-4 text-xs space-y-2 shadow-xl border border-gray-200 max-w-xs">
            <div className="font-bold text-gray-800 mb-2">🗺️ Leyenda del Mapa</div>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(categoryInfo).map(([category, info]) => (
                <div key={category} className="flex items-center space-x-2">
                  <div className={`w-3 h-3 ${info.color} rounded-full flex items-center justify-center`}>
                    <span className="text-xs text-white">{info.icon}</span>
                  </div>
                  <span className="text-gray-700 text-xs">{category}</span>
                </div>
              ))}
            </div>
            <div className="border-t pt-2 mt-3 space-y-1">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-600 rounded-full" />
                <span className="text-gray-700">Tu ubicación</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full" />
                <span className="text-gray-700">Búsqueda</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                <span className="text-gray-700">Urgente</span>
              </div>
            </div>
          </div>
          
          {/* Indicador de zoom */}
          <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-2 shadow-lg">
            <div className="flex items-center space-x-2">
              <Zap className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium">Zoom: {zoomLevel.toFixed(1)}x</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}