import { useState, useEffect } from 'react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { AlertTriangle, Thermometer } from 'lucide-react';

export function ClimateCountdown() {
  const [timeLeft, setTimeLeft] = useState({
    years: 0,
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    // Fecha objetivo: 2030 (punto crítico según estudios climáticos)
    const targetDate = new Date('2030-01-01').getTime();

    const timer = setInterval(() => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference > 0) {
        setTimeLeft({
          years: Math.floor(difference / (1000 * 60 * 60 * 24 * 365)),
          days: Math.floor((difference % (1000 * 60 * 60 * 24 * 365)) / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000)
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <Card className="w-full max-w-4xl mx-auto bg-gradient-to-r from-red-50 to-orange-50 border-red-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-center mb-4">
          <AlertTriangle className="w-6 h-6 text-red-500 mr-2" />
          <h2 className="text-red-700">Cuenta Regresiva Climática</h2>
          <Thermometer className="w-6 h-6 text-red-500 ml-2" />
        </div>
        
        <div className="grid grid-cols-5 gap-4 text-center">
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="text-2xl text-red-600">{timeLeft.years}</div>
            <div className="text-sm text-red-500">Años</div>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="text-2xl text-red-600">{timeLeft.days}</div>
            <div className="text-sm text-red-500">Días</div>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="text-2xl text-red-600">{timeLeft.hours}</div>
            <div className="text-sm text-red-500">Horas</div>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="text-2xl text-red-600">{timeLeft.minutes}</div>
            <div className="text-sm text-red-500">Minutos</div>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="text-2xl text-red-600">{timeLeft.seconds}</div>
            <div className="text-sm text-red-500">Segundos</div>
          </div>
        </div>
        
        <div className="mt-4 text-center">
          <Badge variant="destructive" className="mb-2">
            Punto de No Retorno: 2030
          </Badge>
          <p className="text-sm text-red-600">
            Tiempo restante para limitar el calentamiento global a 1.5°C
          </p>
        </div>
      </CardContent>
    </Card>
  );
}