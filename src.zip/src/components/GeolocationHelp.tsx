import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Smartphone, 
  Laptop, 
  MapPin, 
  Settings, 
  Lock,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

export function GeolocationHelp() {
  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200">
      <CardHeader>
        <CardTitle className="flex items-center">
          <MapPin className="w-5 h-5 mr-2 text-blue-600" />
          ¿Cómo habilitar la ubicación GPS?
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Chrome Desktop */}
        <Alert className="bg-white border-blue-200">
          <Laptop className="w-4 h-4 text-blue-600" />
          <AlertDescription>
            <div className="space-y-2">
              <p className="font-medium text-blue-900">💻 Chrome/Edge en Computadora:</p>
              <ol className="list-decimal list-inside text-sm space-y-1 text-gray-700 ml-2">
                <li>Haz clic en el <Lock className="w-3 h-3 inline text-gray-600" /> <strong>ícono de candado</strong> junto a la URL (arriba a la izquierda)</li>
                <li>Busca <strong>"Ubicación"</strong> en el menú desplegable</li>
                <li>Selecciona <strong>"Permitir"</strong></li>
                <li>Recarga la página (F5)</li>
              </ol>
            </div>
          </AlertDescription>
        </Alert>

        {/* Chrome Mobile */}
        <Alert className="bg-white border-blue-200">
          <Smartphone className="w-4 h-4 text-blue-600" />
          <AlertDescription>
            <div className="space-y-2">
              <p className="font-medium text-blue-900">📱 Chrome en Android/iOS:</p>
              <ol className="list-decimal list-inside text-sm space-y-1 text-gray-700 ml-2">
                <li>Toca el menú <strong>⋮</strong> (tres puntos) arriba a la derecha</li>
                <li>Selecciona <strong>"Configuración del sitio"</strong> o <strong>"Información del sitio"</strong></li>
                <li>Busca <strong>"Permisos"</strong> → <strong>"Ubicación"</strong></li>
                <li>Cambia a <strong>"Permitir"</strong></li>
                <li>Recarga la página</li>
              </ol>
            </div>
          </AlertDescription>
        </Alert>

        {/* Safari */}
        <Alert className="bg-white border-blue-200">
          <Settings className="w-4 h-4 text-blue-600" />
          <AlertDescription>
            <div className="space-y-2">
              <p className="font-medium text-blue-900">🍎 Safari (iPhone/iPad):</p>
              <ol className="list-decimal list-inside text-sm space-y-1 text-gray-700 ml-2">
                <li>Ve a <strong>Ajustes</strong> del iPhone/iPad</li>
                <li>Desplázate hasta <strong>Safari</strong></li>
                <li>Busca <strong>"Ubicación"</strong></li>
                <li>Selecciona <strong>"Preguntar"</strong> o <strong>"Permitir"</strong></li>
                <li>Regresa a GoodImpact y recarga</li>
              </ol>
            </div>
          </AlertDescription>
        </Alert>

        {/* Consejos adicionales */}
        <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div className="space-y-2">
              <p className="font-medium text-green-900">✅ Consejos para mejor precisión GPS:</p>
              <ul className="list-disc list-inside text-sm space-y-1 text-green-800 ml-2">
                <li>Asegúrate de tener el GPS activado en tu dispositivo</li>
                <li>Si estás en interiores, acércate a una ventana</li>
                <li>Espera unos segundos para que el GPS se calibre</li>
                <li>Verifica que tengas conexión a internet</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Ubicación predeterminada */}
        <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-200">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div className="space-y-2">
              <p className="font-medium text-yellow-900">💡 ¿No puedes activar el GPS?</p>
              <p className="text-sm text-yellow-800">
                No te preocupes, GoodImpact automáticamente usará <strong>Yumbo, Valle del Cauca</strong> como ubicación predeterminada. 
                Podrás ver todas las misiones disponibles en la región y buscar por dirección manualmente.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
