import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Users, 
  Star, 
  MapPin, 
  TrendingUp, 
  Heart, 
  Search,
  Filter,
  UserPlus,
  MessageCircle,
  Award,
  Target,
  Sparkles
} from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface MatchedUser {
  id: string;
  name: string;
  avatar: string;
  goodnessLevel: number;
  totalMissions: number;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  distance?: string;
  matchScore: number;
  rank: string;
  badges: string[];
  skills: string[];
  favoriteCategories: string[];
}

interface UserMatcherProps {
  currentUserId?: string;
  userLevel?: number;
}

export function UserMatcher({ currentUserId, userLevel = 500 }: UserMatcherProps) {
  const [matchedUsers, setMatchedUsers] = useState<MatchedUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<'similar' | 'higher' | 'all'>('similar');
  const [selectedUser, setSelectedUser] = useState<MatchedUser | null>(null);

  useEffect(() => {
    loadMatchedUsers();
  }, [selectedLevel]);

  const loadMatchedUsers = async () => {
    setLoading(true);
    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-34f10c60/users/match`;
      const params = new URLSearchParams({
        userId: currentUserId || 'guest',
        userLevel: userLevel.toString(),
        levelFilter: selectedLevel
      });

      const response = await fetch(`${url}?${params.toString()}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && data.users) {
          setMatchedUsers(data.users);
        }
      } else {
        console.error('Error loading matched users:', response.statusText);
      }
    } catch (error) {
      console.error('Error loading matched users:', error);
    }
    setLoading(false);
  };

  const getLevelColor = (level: number) => {
    if (level >= 800) return 'text-purple-600 bg-purple-100';
    if (level >= 600) return 'text-blue-600 bg-blue-100';
    if (level >= 400) return 'text-green-600 bg-green-100';
    if (level >= 200) return 'text-yellow-600 bg-yellow-100';
    return 'text-gray-600 bg-gray-100';
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-blue-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-gray-600';
  };

  const filteredUsers = matchedUsers.filter(user => 
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.location.address.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold flex items-center">
                <Users className="w-8 h-8 mr-3" />
                Encuentra tu Equipo Perfecto
              </h2>
              <p className="text-lg opacity-90 mt-2">
                Conecta con personas de tu mismo nivel para colaborar en misiones
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm opacity-75">Tu nivel de bondad</div>
              <div className="text-4xl font-bold flex items-center">
                <Star className="w-8 h-8 mr-2" />
                {userLevel}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Controles de búsqueda y filtrado */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por nombre o ubicación..."
                className="pl-10"
              />
            </div>
            <div className="flex space-x-2">
              <Button
                variant={selectedLevel === 'similar' ? 'default' : 'outline'}
                onClick={() => setSelectedLevel('similar')}
                className="flex items-center space-x-1"
              >
                <Target className="w-4 h-4" />
                <span>Mismo Nivel</span>
              </Button>
              <Button
                variant={selectedLevel === 'higher' ? 'default' : 'outline'}
                onClick={() => setSelectedLevel('higher')}
                className="flex items-center space-x-1"
              >
                <TrendingUp className="w-4 h-4" />
                <span>Nivel Superior</span>
              </Button>
              <Button
                variant={selectedLevel === 'all' ? 'default' : 'outline'}
                onClick={() => setSelectedLevel('all')}
                className="flex items-center space-x-1"
              >
                <Filter className="w-4 h-4" />
                <span>Todos</span>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de usuarios coincidentes */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              No se encontraron usuarios
            </h3>
            <p className="text-gray-600">
              Intenta cambiar los filtros de búsqueda
            </p>
          </div>
        ) : (
          filteredUsers.map((user) => (
            <Card 
              key={user.id}
              className="hover:shadow-lg transition-all cursor-pointer border-2 hover:border-blue-500"
              onClick={() => setSelectedUser(user)}
            >
              <CardContent className="p-6">
                {/* Avatar y nombre */}
                <div className="flex items-start space-x-4 mb-4">
                  <Avatar className="w-16 h-16">
                    <AvatarImage src={user.avatar} />
                    <AvatarFallback>
                      {user.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{user.name}</h3>
                    <p className="text-sm text-gray-600">{user.rank}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge className={getLevelColor(user.goodnessLevel)}>
                        <Star className="w-3 h-3 mr-1" />
                        {user.goodnessLevel}
                      </Badge>
                      {user.matchScore && (
                        <Badge variant="outline" className={getMatchScoreColor(user.matchScore)}>
                          {user.matchScore}% match
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                {/* Ubicación */}
                <div className="flex items-center space-x-2 text-sm text-gray-600 mb-3">
                  <MapPin className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{user.location.address}</span>
                </div>

                {/* Estadísticas */}
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="text-center p-2 bg-gray-50 rounded">
                    <div className="text-lg font-bold text-blue-600">
                      {user.totalMissions}
                    </div>
                    <div className="text-xs text-gray-600">Misiones</div>
                  </div>
                  <div className="text-center p-2 bg-gray-50 rounded">
                    <div className="text-lg font-bold text-purple-600">
                      {user.badges.length}
                    </div>
                    <div className="text-xs text-gray-600">Insignias</div>
                  </div>
                </div>

                {/* Categorías favoritas */}
                {user.favoriteCategories && user.favoriteCategories.length > 0 && (
                  <div className="mb-4">
                    <div className="text-xs text-gray-500 mb-2">Intereses:</div>
                    <div className="flex flex-wrap gap-1">
                      {user.favoriteCategories.slice(0, 3).map((category, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {category}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Acciones */}
                <div className="flex space-x-2">
                  <Button className="flex-1" size="sm">
                    <UserPlus className="w-4 h-4 mr-1" />
                    Conectar
                  </Button>
                  <Button variant="outline" size="sm">
                    <MessageCircle className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Modal de perfil detallado */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-4">
                  <Avatar className="w-20 h-20">
                    <AvatarImage src={selectedUser.avatar} />
                    <AvatarFallback>
                      {selectedUser.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-2xl">{selectedUser.name}</CardTitle>
                    <p className="text-gray-600">{selectedUser.rank}</p>
                    <Badge className={`mt-2 ${getLevelColor(selectedUser.goodnessLevel)}`}>
                      <Star className="w-4 h-4 mr-1" />
                      Nivel {selectedUser.goodnessLevel}
                    </Badge>
                  </div>
                </div>
                <Button variant="ghost" onClick={() => setSelectedUser(null)}>
                  ✕
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              {/* Compatibilidad */}
              {selectedUser.matchScore && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Compatibilidad</span>
                    <span className={`font-bold ${getMatchScoreColor(selectedUser.matchScore)}`}>
                      {selectedUser.matchScore}%
                    </span>
                  </div>
                  <Progress value={selectedUser.matchScore} className="h-3" />
                  <p className="text-sm text-gray-600 mt-2">
                    {selectedUser.matchScore >= 90 ? '¡Excelente coincidencia! Tienen intereses muy similares.' :
                     selectedUser.matchScore >= 70 ? 'Buena coincidencia. Comparten varios intereses.' :
                     'Pueden aprender mucho trabajando juntos.'}
                  </p>
                </div>
              )}

              {/* Ubicación */}
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <MapPin className="w-5 h-5 text-blue-600" />
                  <span className="font-medium">Ubicación</span>
                </div>
                <p className="text-gray-700">{selectedUser.location.address}</p>
                {selectedUser.distance && (
                  <p className="text-sm text-gray-500 mt-1">A {selectedUser.distance} de distancia</p>
                )}
              </div>

              {/* Insignias */}
              {selectedUser.badges.length > 0 && (
                <div>
                  <div className="flex items-center space-x-2 mb-3">
                    <Award className="w-5 h-5 text-yellow-600" />
                    <span className="font-medium">Insignias</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedUser.badges.map((badge, idx) => (
                      <Badge key={idx} variant="outline" className="bg-yellow-50 text-yellow-800">
                        🏆 {badge}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Habilidades */}
              {selectedUser.skills && selectedUser.skills.length > 0 && (
                <div>
                  <div className="flex items-center space-x-2 mb-3">
                    <Sparkles className="w-5 h-5 text-purple-600" />
                    <span className="font-medium">Habilidades</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedUser.skills.map((skill, idx) => (
                      <Badge key={idx} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Acciones */}
              <div className="flex space-x-3 pt-4">
                <Button className="flex-1 bg-blue-600 hover:bg-blue-700">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Enviar Solicitud de Conexión
                </Button>
                <Button variant="outline" className="flex-1">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Enviar Mensaje
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
