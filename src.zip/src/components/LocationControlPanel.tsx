import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { 
  Navigation, 
  Zap, 
  MapPin, 
  Settings,
  Info,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { motion } from 'motion/react';

interface LocationControlPanelProps {
  isTracking: boolean;
  permissionState: 'unknown' | 'granted' | 'denied' | 'prompt';
  onToggleTracking: (enabled: boolean) => void;
  onRequestPermission: () => void;
  accuracy?: number;
  lastUpdate?: Date | null;
}

export function LocationControlPanel({
  isTracking,
  permissionState,
  onToggleTracking,
  onRequestPermission,
  accuracy,
  lastUpdate
}: LocationControlPanelProps) {
  
  const getPermissionStatus = () => {
    switch (permissionState) {
      case 'granted':
        return { 
          icon: <CheckCircle className="w-4 h-4 text-green-600" />, 
          text: 'Concedido', 
          color: 'text-green-600',
          bgColor: 'bg-green-50'
        };
      case 'denied':
        return { 
          icon: <XCircle className="w-4 h-4 text-red-600" />, 
          text: 'Denegado', 
          color: 'text-red-600',
          bgColor: 'bg-red-50'
        };
      case 'prompt':
        return { 
          icon: <Info className="w-4 h-4 text-blue-600" />, 
          text: 'Pendiente', 
          color: 'text-blue-600',
          bgColor: 'bg-blue-50'
        };
      default:
        return { 
          icon: <Info className="w-4 h-4 text-gray-600" />, 
          text: 'Desconocido', 
          color: 'text-gray-600',
          bgColor: 'bg-gray-50'
        };
    }
  };

  const status = getPermissionStatus();

  return (
    <Card className="border-2 border-blue-200">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Settings className="w-5 h-5 text-blue-600" />
          <span>Control de Ubicación GPS</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Estado de permisos */}
        <div className={`p-3 rounded-lg ${status.bgColor} border border-${status.color.split('-')[1]}-200`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {status.icon}
              <span className="text-sm font-medium">Permisos de ubicación:</span>
            </div>
            <Badge className={status.color} variant="outline">
              {status.text}
            </Badge>
          </div>
        </div>

        {/* Control de tracking en tiempo real */}
        {permissionState === 'granted' && (
          <motion.div 
            className="p-3 rounded-lg bg-green-50 border border-green-200"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="tracking-mode" 
                    checked={isTracking}
                    onCheckedChange={onToggleTracking}
                  />
                  <Label htmlFor="tracking-mode" className="flex items-center space-x-2 cursor-pointer">
                    <Zap className="w-4 h-4 text-green-600" />
                    <span>Tracking en Tiempo Real</span>
                  </Label>
                </div>
              </div>
              {isTracking && (
                <Badge className="bg-green-600 text-white animate-pulse">
                  ACTIVO
                </Badge>
              )}
            </div>
            
            {isTracking && (
              <div className="mt-3 pt-3 border-t border-green-200 grid grid-cols-2 gap-3">
                {accuracy && (
                  <div className="text-xs">
                    <span className="text-gray-600">Precisión:</span>
                    <span className="ml-1 font-medium text-green-700">±{Math.round(accuracy)}m</span>
                  </div>
                )}
                {lastUpdate && (
                  <div className="text-xs">
                    <span className="text-gray-600">Actualizado:</span>
                    <span className="ml-1 font-medium text-green-700">
                      {lastUpdate.toLocaleTimeString()}
                    </span>
                  </div>
                )}
              </div>
            )}

            <p className="text-xs text-green-700 mt-2">
              ℹ️ Tu ubicación se actualiza automáticamente mientras navegas
            </p>
          </motion.div>
        )}

        {/* Botón para solicitar permisos */}
        {permissionState !== 'granted' && (
          <div className="space-y-2">
            <Button 
              onClick={onRequestPermission}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              <Navigation className="w-4 h-4 mr-2" />
              {permissionState === 'denied' 
                ? 'Abrir Configuración de Permisos' 
                : 'Activar Ubicación GPS'}
            </Button>
            
            {permissionState === 'denied' && (
              <p className="text-xs text-gray-600 text-center">
                Debes permitir el acceso en la configuración de tu navegador
              </p>
            )}
          </div>
        )}

        {/* Información sobre el tracking */}
        <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
          <div className="flex items-start space-x-2">
            <Info className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-xs font-medium text-blue-900">
                ¿Cómo funciona el tracking en tiempo real?
              </p>
              <ul className="text-xs text-blue-800 space-y-1 list-disc list-inside">
                <li>GPS de alta precisión para mejor exactitud</li>
                <li>Actualización continua de tu posición</li>
                <li>Misiones ordenadas por distancia en tiempo real</li>
                <li>Navegación optimizada a misiones cercanas</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Estadísticas */}
        {isTracking && (
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-white p-2 rounded border text-center">
              <MapPin className="w-4 h-4 text-blue-600 mx-auto mb-1" />
              <p className="text-xs font-medium">GPS Activo</p>
            </div>
            <div className="bg-white p-2 rounded border text-center">
              <Zap className="w-4 h-4 text-green-600 mx-auto mb-1" />
              <p className="text-xs font-medium">Tiempo Real</p>
            </div>
            <div className="bg-white p-2 rounded border text-center">
              <CheckCircle className="w-4 h-4 text-purple-600 mx-auto mb-1" />
              <p className="text-xs font-medium">Alta Precisión</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
