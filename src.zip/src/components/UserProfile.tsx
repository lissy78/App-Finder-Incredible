import { useState } from 'react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Star, 
  Award, 
  Leaf, 
  Heart, 
  Users, 
  Target, 
  Calendar,
  MapPin,
  TrendingUp,
  Gift
} from 'lucide-react';

interface UserStats {
  goodnessLevel: number;
  totalMissions: number;
  helpedPeople: number;
  carbonSaved: number;
  streak: number;
  rank: string;
  badges: string[];
  nextLevelProgress: number;
}

const mockUserStats: UserStats = {
  goodnessLevel: 847,
  totalMissions: 156,
  helpedPeople: 1243,
  carbonSaved: 2.8,
  streak: 23,
  rank: 'Héroe Ambiental',
  badges: ['Eco Warrior', 'Code for Good', 'Community Builder', 'Climate Champion'],
  nextLevelProgress: 73
};

const recentAchievements = [
  { title: 'Primer Mes Completo', description: 'Completaste misiones todos los días del mes', icon: Calendar, color: 'text-blue-500' },
  { title: 'Mentor de Código', description: 'Enseñaste programación a 50+ estudiantes', icon: Users, color: 'text-purple-500' },
  { title: 'Guardián Verde', description: 'Salvaste 1 tonelada de CO2 este año', icon: Leaf, color: 'text-green-500' },
  { title: 'Corazón de Oro', description: 'Ayudaste a 1000+ personas', icon: Heart, color: 'text-red-500' }
];

const impactMetrics = [
  { label: 'Personas Ayudadas', value: '1,243', icon: Users, color: 'text-blue-600' },
  { label: 'CO2 Ahorrado (ton)', value: '2.8', icon: Leaf, color: 'text-green-600' },
  { label: 'Proyectos Completados', value: '34', icon: Target, color: 'text-purple-600' },
  { label: 'Días de Racha', value: '23', icon: TrendingUp, color: 'text-orange-600' }
];

export function UserProfile() {
  const [selectedTab, setSelectedTab] = useState('overview');

  const getGoodnessLevelColor = (level: number) => {
    if (level >= 800) return 'text-purple-600';
    if (level >= 600) return 'text-blue-600';
    if (level >= 400) return 'text-green-600';
    if (level >= 200) return 'text-yellow-600';
    return 'text-gray-600';
  };

  const getGoodnessLevelBg = (level: number) => {
    if (level >= 800) return 'bg-purple-100';
    if (level >= 600) return 'bg-blue-100';
    if (level >= 400) return 'bg-green-100';
    if (level >= 200) return 'bg-yellow-100';
    return 'bg-gray-100';
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Header del perfil */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center space-x-6">
            <Avatar className="w-24 h-24">
              <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b612b169" />
              <AvatarFallback>EV</AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h2>Elena Verde</h2>
                <Badge className={`${getGoodnessLevelBg(mockUserStats.goodnessLevel)} ${getGoodnessLevelColor(mockUserStats.goodnessLevel)}`}>
                  <Star className="w-4 h-4 mr-1" />
                  {mockUserStats.goodnessLevel} Nivel de Bondad
                </Badge>
              </div>
              
              <p className="text-gray-600 mb-3">{mockUserStats.rank}</p>
              
              <div className="flex items-center space-x-1 text-sm text-gray-500 mb-4">
                <MapPin className="w-4 h-4" />
                <span>Yumbo, Valle del Cauca, Colombia</span>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Progreso al siguiente nivel</span>
                  <span>{mockUserStats.nextLevelProgress}%</span>
                </div>
                <Progress value={mockUserStats.nextLevelProgress} className="w-full" />
              </div>
            </div>
            
            <div className="text-center">
              <Button className="mb-2">
                <Gift className="w-4 h-4 mr-2" />
                Enviar Regalo
              </Button>
              <Button variant="outline">
                Ver Perfil Completo
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs de contenido */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Resumen</TabsTrigger>
          <TabsTrigger value="achievements">Logros</TabsTrigger>
          <TabsTrigger value="impact">Impacto</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Estadísticas principales */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <Target className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                <div className="font-semibold">{mockUserStats.totalMissions}</div>
                <div className="text-sm text-gray-600">Misiones</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <Users className="w-8 h-8 mx-auto mb-2 text-green-600" />
                <div className="font-semibold">{mockUserStats.helpedPeople.toLocaleString()}</div>
                <div className="text-sm text-gray-600">Personas Ayudadas</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <Leaf className="w-8 h-8 mx-auto mb-2 text-emerald-600" />
                <div className="font-semibold">{mockUserStats.carbonSaved}t</div>
                <div className="text-sm text-gray-600">CO2 Ahorrado</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <TrendingUp className="w-8 h-8 mx-auto mb-2 text-orange-600" />
                <div className="font-semibold">{mockUserStats.streak}</div>
                <div className="text-sm text-gray-600">Días de Racha</div>
              </CardContent>
            </Card>
          </div>

          {/* Insignias */}
          <Card>
            <CardHeader>
              <h3 className="flex items-center space-x-2">
                <Award className="w-5 h-5 text-yellow-600" />
                <span>Insignias Destacadas</span>
              </h3>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {mockUserStats.badges.map((badge, index) => (
                  <div key={index} className="text-center">
                    <div className="w-16 h-16 mx-auto mb-2 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                      <Award className="w-8 h-8 text-white" />
                    </div>
                    <p className="text-sm font-medium">{badge}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-6">
          <Card>
            <CardHeader>
              <h3>Logros Recientes</h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentAchievements.map((achievement, index) => (
                  <div key={index} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                    <div className={`w-12 h-12 rounded-full bg-white flex items-center justify-center ${achievement.color}`}>
                      <achievement.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-medium">{achievement.title}</h4>
                      <p className="text-sm text-gray-600">{achievement.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="impact" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {impactMetrics.map((metric, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center ${metric.color}`}>
                      <metric.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{metric.value}</div>
                      <div className="text-sm text-gray-600">{metric.label}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <Card>
            <CardHeader>
              <h3>Impacto a lo Largo del Tiempo</h3>
            </CardHeader>
            <CardContent>
              <div className="h-32 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg flex items-center justify-center">
                <p className="text-gray-600">Gráfico de impacto simulado</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}