import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { 
  Download, 
  Share2, 
  Verified, 
  Trophy, 
  Star, 
  Calendar,
  MapPin,
  Users,
  Clock,
  Medal,
  Award,
  Crown,
  Zap,
  Heart,
  Target,
  TrendingUp,
  CheckCircle,
  Gift
} from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface CompletedMission {
  id: string;
  title: string;
  category: string;
  difficulty: string;
  completedAt: string;
  verifiedBy: string;
  rating: number;
  paymentReceived: string;
  testimonial?: string;
  proofImages?: string[];
  skillsLearned: string[];
  location: string;
  duration: string;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedAt: string;
  category: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

interface UserStats {
  totalMissions: number;
  totalEarnings: number;
  averageRating: number;
  skillsCount: number;
  currentStreak: number;
  longestStreak: number;
  favoriteCategory: string;
  totalHoursWorked: number;
  peopleHelped: number;
  carbonSaved: number;
}

export function DigitalResume() {
  const [userData, setUserData] = useState<any>(null);
  const [completedMissions, setCompletedMissions] = useState<CompletedMission[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [stats, setStats] = useState<UserStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadResumeData();
  }, []);

  const loadResumeData = async () => {
    setLoading(true);
    try {
      // Datos mock para demostración
      const mockCompletedMissions: CompletedMission[] = [
        {
          id: '1',
          title: 'Limpieza del Parque Central',
          category: 'Medio Ambiente',
          difficulty: 'Fácil',
          completedAt: '2024-01-15T10:00:00Z',
          verifiedBy: 'María González - Alcaldía Yumbo',
          rating: 5,
          paymentReceived: '$25,000 COP + Almuerzo',
          testimonial: '¡Excelente trabajo! Dejó el parque impecable y trabajó con mucha dedicación.',
          skillsLearned: ['Trabajo en equipo', 'Responsabilidad ambiental', 'Liderazgo'],
          location: 'Parque Central, Yumbo',
          duration: '3 horas'
        },
        {
          id: '2',
          title: 'Creación de página web para panadería',
          category: 'Tecnología',
          difficulty: 'Medio',
          completedAt: '2024-01-20T15:30:00Z',
          verifiedBy: 'Carlos Ramírez - Panadería Don Carlos',
          rating: 5,
          paymentReceived: '$80,000 COP + Pan gratis por 1 mes',
          testimonial: 'Increíble trabajo para su edad. La página quedó perfecta y aumentamos las ventas 40%.',
          skillsLearned: ['HTML/CSS', 'Diseño web', 'Atención al cliente', 'Marketing digital'],
          location: 'Centro Comercial Yumbo',
          duration: '1 semana'
        },
        {
          id: '3',
          title: 'Enseñanza de matemáticas a niños',
          category: 'Educación',
          difficulty: 'Fácil',
          completedAt: '2024-01-25T16:00:00Z',
          verifiedBy: 'Ana Lucía Torres - Directora Escuela',
          rating: 5,
          paymentReceived: 'Intercambio: Clases de guitarra',
          testimonial: 'Los niños mejoraron muchísimo. Tiene un don natural para enseñar.',
          skillsLearned: ['Pedagogía', 'Paciencia', 'Comunicación', 'Matemáticas avanzadas'],
          location: 'Escuela San José, Yumbo',
          duration: '2 semanas'
        }
      ];

      const mockAchievements: Achievement[] = [
        {
          id: '1',
          name: 'Primer Paso',
          description: 'Completaste tu primera misión',
          icon: '🏆',
          unlockedAt: '2024-01-15T10:00:00Z',
          category: 'Progreso',
          rarity: 'common'
        },
        {
          id: '2',
          name: 'Eco Guerrero',
          description: 'Completaste 5 misiones ambientales',
          icon: '🌱',
          unlockedAt: '2024-01-20T15:30:00Z',
          category: 'Medio Ambiente',
          rarity: 'rare'
        },
        {
          id: '3',
          name: 'Tech Genius',
          description: 'Completaste una misión de tecnología con 5 estrellas',
          icon: '💻',
          unlockedAt: '2024-01-20T15:30:00Z',
          category: 'Tecnología',
          rarity: 'epic'
        },
        {
          id: '4',
          name: 'Maestro de Corazones',
          description: 'Recibiste 5 testimonios de 5 estrellas',
          icon: '💝',
          unlockedAt: '2024-01-25T16:00:00Z',
          category: 'Excelencia',
          rarity: 'legendary'
        }
      ];

      const mockStats: UserStats = {
        totalMissions: 15,
        totalEarnings: 250000,
        averageRating: 4.9,
        skillsCount: 12,
        currentStreak: 8,
        longestStreak: 12,
        favoriteCategory: 'Tecnología',
        totalHoursWorked: 45,
        peopleHelped: 23,
        carbonSaved: 2.3
      };

      setCompletedMissions(mockCompletedMissions);
      setAchievements(mockAchievements);
      setStats(mockStats);
      setUserData({
        name: 'Alejandro Martínez',
        age: 14,
        location: 'Yumbo, Valle del Cauca',
        joinedAt: '2024-01-10',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d'
      });
    } catch (error) {
      console.error('Error loading resume data:', error);
    }
    setLoading(false);
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-gray-100 text-gray-800 border-gray-300';
      case 'rare': return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'epic': return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'legendary': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const shareResume = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Currículum de ${userData?.name} - GoodImpact`,
          text: `¡Mira todo lo que he logrado en GoodImpact! ${stats?.totalMissions} misiones completadas con una calificación promedio de ${stats?.averageRating}⭐`,
          url: window.location.href
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      // Fallback para navegadores que no soportan Web Share API
      navigator.clipboard.writeText(
        `¡Mira mi currículum en GoodImpact! ${stats?.totalMissions} misiones completadas con ${stats?.averageRating}⭐ de calificación promedio. ${window.location.href}`
      );
      alert('¡Enlace copiado al portapapeles!');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {/* Header del currículum */}
      <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <CardContent className="p-8">
          <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
            <Avatar className="w-24 h-24 border-4 border-white">
              <AvatarImage src={userData?.avatar} />
              <AvatarFallback className="text-2xl bg-white text-blue-600">
                {userData?.name?.split(' ').map((n: string) => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-3xl font-bold flex items-center justify-center md:justify-start">
                {userData?.name}
                <Verified className="w-6 h-6 ml-2 text-yellow-300" />
              </h1>
              <p className="text-xl opacity-90">{userData?.age} años • {userData?.location}</p>
              <p className="opacity-75">Héroe de GoodImpact desde {new Date(userData?.joinedAt).toLocaleDateString('es', { year: 'numeric', month: 'long' })}</p>
              
              <div className="flex flex-wrap justify-center md:justify-start gap-2 mt-4">
                <Badge className="bg-white/20 text-white border-white/30">
                  ⭐ {stats?.averageRating}/5.0
                </Badge>
                <Badge className="bg-white/20 text-white border-white/30">
                  🎯 {stats?.totalMissions} misiones
                </Badge>
                <Badge className="bg-white/20 text-white border-white/30">
                  🔥 {stats?.currentStreak} días activo
                </Badge>
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button variant="secondary" onClick={shareResume}>
                <Share2 className="w-4 h-4 mr-2" />
                Compartir
              </Button>
              <Button variant="secondary">
                <Download className="w-4 h-4 mr-2" />
                Descargar PDF
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="estadisticas" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="estadisticas">📊 Estadísticas</TabsTrigger>
          <TabsTrigger value="misiones">✅ Misiones</TabsTrigger>
          <TabsTrigger value="logros">🏆 Logros</TabsTrigger>
          <TabsTrigger value="habilidades">⚡ Habilidades</TabsTrigger>
        </TabsList>

        <TabsContent value="estadisticas">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="text-center">
              <CardContent className="p-6">
                <Target className="w-8 h-8 mx-auto text-blue-600 mb-2" />
                <div className="text-3xl font-bold text-blue-600">{stats?.totalMissions}</div>
                <p className="text-gray-600">Misiones Completadas</p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <Gift className="w-8 h-8 mx-auto text-green-600 mb-2" />
                <div className="text-3xl font-bold text-green-600">${stats?.totalEarnings.toLocaleString()}</div>
                <p className="text-gray-600">COP Ganados</p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <Star className="w-8 h-8 mx-auto text-yellow-600 mb-2" />
                <div className="text-3xl font-bold text-yellow-600">{stats?.averageRating}</div>
                <p className="text-gray-600">Calificación Promedio</p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <Heart className="w-8 h-8 mx-auto text-red-600 mb-2" />
                <div className="text-3xl font-bold text-red-600">{stats?.peopleHelped}</div>
                <p className="text-gray-600">Personas Ayudadas</p>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2" />
                  Progreso del Mes
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Meta de misiones (10)</span>
                    <span>8/10</span>
                  </div>
                  <Progress value={80} className="h-3" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Horas trabajadas (40h)</span>
                    <span>32/40</span>
                  </div>
                  <Progress value={80} className="h-3" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Categorías exploradas (5)</span>
                    <span>4/5</span>
                  </div>
                  <Progress value={80} className="h-3" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="w-5 h-5 mr-2" />
                  Racha Actual
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="text-6xl font-bold text-orange-600 mb-2">
                  🔥 {stats?.currentStreak}
                </div>
                <p className="text-gray-600 mb-4">días consecutivos activo</p>
                <Badge variant="outline" className="text-gray-600">
                  Récord: {stats?.longestStreak} días
                </Badge>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="misiones">
          <div className="space-y-4">
            {completedMissions.map((mission) => (
              <Card key={mission.id} className="border-l-4 border-l-green-500">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-start justify-between space-y-4 md:space-y-0">
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-xl font-bold flex items-center">
                            {mission.title}
                            <CheckCircle className="w-5 h-5 ml-2 text-green-600" />
                          </h3>
                          <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                            <span className="flex items-center">
                              <Calendar className="w-4 h-4 mr-1" />
                              {new Date(mission.completedAt).toLocaleDateString('es')}
                            </span>
                            <span className="flex items-center">
                              <MapPin className="w-4 h-4 mr-1" />
                              {mission.location}
                            </span>
                            <span className="flex items-center">
                              <Clock className="w-4 h-4 mr-1" />
                              {mission.duration}
                            </span>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="flex items-center space-x-1 mb-1">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={`w-4 h-4 ${i < mission.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                              />
                            ))}
                          </div>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {mission.paymentReceived}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-2 mb-3">
                        <Badge variant="secondary">{mission.category}</Badge>
                        <Badge variant="outline">{mission.difficulty}</Badge>
                        {mission.skillsLearned.map((skill) => (
                          <Badge key={skill} variant="outline" className="bg-blue-50 text-blue-700">
                            ⚡ {skill}
                          </Badge>
                        ))}
                      </div>
                      
                      {mission.testimonial && (
                        <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-l-blue-500">
                          <p className="italic text-gray-700">"{mission.testimonial}"</p>
                          <p className="text-sm text-gray-600 mt-2 font-medium">
                            - {mission.verifiedBy} <Verified className="w-4 h-4 inline text-blue-600" />
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="logros">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {achievements.map((achievement) => (
              <Card key={achievement.id} className={`border-2 ${getRarityColor(achievement.rarity)}`}>
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-3">{achievement.icon}</div>
                  <h3 className="font-bold text-lg mb-2">{achievement.name}</h3>
                  <p className="text-gray-600 mb-3">{achievement.description}</p>
                  <div className="flex flex-col space-y-2">
                    <Badge className={getRarityColor(achievement.rarity)}>
                      {achievement.rarity.toUpperCase()}
                    </Badge>
                    <p className="text-xs text-gray-500">
                      Desbloqueado el {new Date(achievement.unlockedAt).toLocaleDateString('es')}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="habilidades">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>💻 Habilidades Técnicas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>HTML/CSS</span>
                    <span>Avanzado</span>
                  </div>
                  <Progress value={85} className="h-3" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>JavaScript</span>
                    <span>Intermedio</span>
                  </div>
                  <Progress value={70} className="h-3" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Diseño Web</span>
                    <span>Avanzado</span>
                  </div>
                  <Progress value={80} className="h-3" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>🤝 Habilidades Sociales</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Trabajo en Equipo</span>
                    <span>Experto</span>
                  </div>
                  <Progress value={95} className="h-3" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Comunicación</span>
                    <span>Avanzado</span>
                  </div>
                  <Progress value={88} className="h-3" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Liderazgo</span>
                    <span>Intermedio</span>
                  </div>
                  <Progress value={75} className="h-3" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}