import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { 
  CheckCircle, 
  Camera, 
  Upload, 
  Star, 
  Clock,
  MapPin,
  DollarSign,
  Users,
  Sparkles,
  Trophy,
  Heart,
  Zap
} from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Mission {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  reward: number;
  paymentOptions: any[];
  timeEstimate: string;
  location: { address: string };
  maxParticipants: number;
  participants: number;
}

interface MissionCompletionProps {
  mission: Mission;
  onComplete: () => void;
  onCancel: () => void;
}

export function MissionCompletion({ mission, onComplete, onCancel }: MissionCompletionProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    proofDescription: '',
    completionNotes: '',
    timeSpent: '',
    skillsLearned: [] as string[],
    newSkill: '',
    selfRating: 5,
    wouldRecommend: true
  });
  const [loading, setLoading] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);

  const skillSuggestions = [
    'Trabajo en equipo', 'Responsabilidad', 'Puntualidad', 'Creatividad',
    'Comunicación', 'Liderazgo', 'Resolución de problemas', 'Paciencia',
    'Organización', 'Atención al detalle', 'Adaptabilidad', 'Perseverancia'
  ];

  const addSkill = (skill: string) => {
    if (!formData.skillsLearned.includes(skill)) {
      setFormData({
        ...formData,
        skillsLearned: [...formData.skillsLearned, skill]
      });
    }
  };

  const removeSkill = (skill: string) => {
    setFormData({
      ...formData,
      skillsLearned: formData.skillsLearned.filter(s => s !== skill)
    });
  };

  const addCustomSkill = () => {
    if (formData.newSkill && !formData.skillsLearned.includes(formData.newSkill)) {
      setFormData({
        ...formData,
        skillsLearned: [...formData.skillsLearned, formData.newSkill],
        newSkill: ''
      });
    }
  };

  const submitCompletion = async () => {
    setLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-34f10c60/missions/${mission.id}/complete`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          setStep(4); // Paso de éxito
        }
      }
    } catch (error) {
      console.error('Error submitting completion:', error);
      alert('Error al enviar la finalización. ¡Inténtalo de nuevo!');
    }
    setLoading(false);
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="w-8 h-8 text-green-600" />
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-2">¡Misión Completada!</h3>
        <p className="text-gray-600">Cuéntanos cómo te fue para poder verificar tu trabajo</p>
      </div>

      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <h4 className="font-bold text-lg mb-2">{mission.title}</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-gray-500" />
              <span>{mission.location.address}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-gray-500" />
              <span>{mission.timeEstimate}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Star className="w-4 h-4 text-yellow-500" />
              <span>{mission.reward} puntos</span>
            </div>
            <div className="flex items-center space-x-2">
              <DollarSign className="w-4 h-4 text-green-500" />
              <span>{mission.paymentOptions[0]?.description || 'Pago acordado'}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div>
          <Label htmlFor="proofDescription" className="text-lg font-medium">
            📝 ¿Qué hiciste exactamente?
          </Label>
          <Textarea
            id="proofDescription"
            value={formData.proofDescription}
            onChange={(e) => setFormData({...formData, proofDescription: e.target.value})}
            placeholder="Describe detalladamente lo que hiciste, cómo lo hiciste y qué resultado obtuviste..."
            rows={4}
            className="mt-2"
          />
        </div>

        <div>
          <Label htmlFor="timeSpent" className="text-lg font-medium">
            ⏱️ ¿Cuánto tiempo tomó realmente?
          </Label>
          <Input
            id="timeSpent"
            value={formData.timeSpent}
            onChange={(e) => setFormData({...formData, timeSpent: e.target.value})}
            placeholder="Ej: 2 horas y 30 minutos"
            className="mt-2"
          />
        </div>

        <div>
          <Label className="text-lg font-medium">
            📸 ¿Tienes fotos del trabajo realizado?
          </Label>
          <div className="mt-2 border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            <Camera className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-600 mb-2">Toma fotos del antes y después (opcional)</p>
            <Button variant="outline" size="sm">
              <Upload className="w-4 h-4 mr-2" />
              Subir Fotos
            </Button>
          </div>
        </div>
      </div>

      <div className="flex space-x-4">
        <Button variant="outline" onClick={onCancel} className="flex-1">
          Cancelar
        </Button>
        <Button 
          onClick={() => setStep(2)} 
          disabled={!formData.proofDescription.trim()}
          className="flex-1 bg-blue-600 hover:bg-blue-700"
        >
          Continuar
          <Sparkles className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Zap className="w-8 h-8 text-purple-600" />
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-2">¿Qué aprendiste?</h3>
        <p className="text-gray-600">Esto ayudará a construir tu currículum automáticamente</p>
      </div>

      <div className="space-y-4">
        <div>
          <Label className="text-lg font-medium">
            🧠 Habilidades que desarrollaste o practicaste
          </Label>
          <div className="mt-2 space-y-3">
            <div className="flex flex-wrap gap-2">
              {skillSuggestions.map((skill) => (
                <Button
                  key={skill}
                  variant={formData.skillsLearned.includes(skill) ? "default" : "outline"}
                  size="sm"
                  onClick={() => formData.skillsLearned.includes(skill) ? removeSkill(skill) : addSkill(skill)}
                  className="text-sm"
                >
                  {formData.skillsLearned.includes(skill) && <CheckCircle className="w-3 h-3 mr-1" />}
                  {skill}
                </Button>
              ))}
            </div>
            
            <div className="flex space-x-2">
              <Input
                value={formData.newSkill}
                onChange={(e) => setFormData({...formData, newSkill: e.target.value})}
                placeholder="¿Otra habilidad?"
                className="flex-1"
              />
              <Button onClick={addCustomSkill} variant="outline">
                Agregar
              </Button>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-medium mb-2">Habilidades seleccionadas:</h4>
          <div className="flex flex-wrap gap-2">
            {formData.skillsLearned.map((skill) => (
              <Badge key={skill} variant="secondary" className="bg-blue-100 text-blue-800">
                ⚡ {skill}
                <button 
                  onClick={() => removeSkill(skill)}
                  className="ml-2 text-blue-600 hover:text-blue-800"
                >
                  ×
                </button>
              </Badge>
            ))}
          </div>
        </div>

        <div>
          <Label htmlFor="completionNotes" className="text-lg font-medium">
            💭 Comentarios adicionales (opcional)
          </Label>
          <Textarea
            id="completionNotes"
            value={formData.completionNotes}
            onChange={(e) => setFormData({...formData, completionNotes: e.target.value})}
            placeholder="¿Algo más que quieras agregar? ¿Desafíos que superaste? ¿Ideas para mejorar?"
            rows={3}
            className="mt-2"
          />
        </div>
      </div>

      <div className="flex space-x-4">
        <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
          Atrás
        </Button>
        <Button 
          onClick={() => setStep(3)} 
          className="flex-1 bg-purple-600 hover:bg-purple-700"
        >
          Continuar
          <Sparkles className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Star className="w-8 h-8 text-yellow-600" />
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-2">Autoevaluación</h3>
        <p className="text-gray-600">¿Cómo calificarías tu propio trabajo?</p>
      </div>

      <div className="space-y-6">
        <div className="text-center">
          <Label className="text-lg font-medium mb-4 block">
            ⭐ Tu calificación personal
          </Label>
          <div className="flex justify-center space-x-2 mb-4">
            {[1, 2, 3, 4, 5].map((rating) => (
              <button
                key={rating}
                onClick={() => setFormData({...formData, selfRating: rating})}
                className="focus:outline-none"
              >
                <Star 
                  className={`w-8 h-8 ${rating <= formData.selfRating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                />
              </button>
            ))}
          </div>
          <p className="text-sm text-gray-600">
            {formData.selfRating === 5 ? '¡Excelente trabajo!' :
             formData.selfRating === 4 ? 'Muy buen trabajo' :
             formData.selfRating === 3 ? 'Buen trabajo' :
             formData.selfRating === 2 ? 'Trabajo aceptable' :
             'Trabajo básico'}
          </p>
        </div>

        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-6">
            <h4 className="font-bold text-lg mb-4 text-center">🎁 ¡Tu recompensa!</h4>
            <div className="grid grid-cols-2 gap-4 text-center">
              <div>
                <Trophy className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-yellow-600">{mission.reward}</div>
                <p className="text-sm text-gray-600">Puntos de Bondad</p>
              </div>
              <div>
                <DollarSign className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <div className="text-lg font-bold text-green-600">
                  {mission.paymentOptions[0]?.description || 'Pago acordado'}
                </div>
                <p className="text-sm text-gray-600">Pago prometido</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
          <h4 className="font-medium text-blue-900 mb-2">📋 ¿Qué pasa ahora?</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• El creador de la misión recibirá una notificación</li>
            <li>• Revisará tu trabajo y confirmará el pago</li>
            <li>• Una vez verificado, ganarás tus puntos y se agregará a tu currículum</li>
            <li>• ¡Tu reputación como héroe de bondad aumentará!</li>
          </ul>
        </div>
      </div>

      <div className="flex space-x-4">
        <Button variant="outline" onClick={() => setStep(2)} className="flex-1">
          Atrás
        </Button>
        <Button 
          onClick={submitCompletion} 
          disabled={loading}
          className="flex-1 bg-green-600 hover:bg-green-700"
        >
          {loading ? (
            <>
              <Heart className="w-4 h-4 mr-2 animate-pulse" />
              Enviando...
            </>
          ) : (
            <>
              <CheckCircle className="w-4 h-4 mr-2" />
              Enviar para Verificación
            </>
          )}
        </Button>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6 text-center">
      <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto">
        <Trophy className="w-12 h-12 text-green-600" />
      </div>
      
      <div>
        <h3 className="text-3xl font-bold text-gray-900 mb-2">¡Felicidades! 🎉</h3>
        <p className="text-xl text-gray-600 mb-4">Tu misión ha sido enviada para verificación</p>
        <p className="text-gray-600">
          El creador de la misión revisará tu trabajo y confirmará el pago. 
          Te notificaremos cuando esté listo.
        </p>
      </div>

      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardContent className="p-6">
          <h4 className="font-bold text-lg mb-4">📈 Tu progreso</h4>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600">+{mission.reward}</div>
              <p className="text-sm text-gray-600">Puntos ganados*</p>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">+{formData.skillsLearned.length}</div>
              <p className="text-sm text-gray-600">Habilidades</p>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">+1</div>
              <p className="text-sm text-gray-600">Misión completa</p>
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-2">*Pendiente de verificación</p>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <Button onClick={onComplete} className="w-full bg-blue-600 hover:bg-blue-700">
          Ver Mis Misiones
        </Button>
        <Button variant="outline" onClick={onCancel} className="w-full">
          Buscar Más Misiones
        </Button>
      </div>
    </div>
  );

  return (
    <div className="w-full max-w-2xl mx-auto">
      <Card className="border-2 border-green-200 shadow-xl">
        <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50">
          <CardTitle className="flex items-center justify-between">
            <span>Completar Misión</span>
            <Badge variant="outline" className="bg-white">
              Paso {step} de 3
            </Badge>
          </CardTitle>
          
          {/* Progress bar */}
          <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
            <div 
              className="bg-gradient-to-r from-green-600 to-blue-600 h-2 rounded-full transition-all duration-300" 
              style={{ width: `${(step / 3) * 100}%` }}
            ></div>
          </div>
        </CardHeader>
        
        <CardContent className="p-6">
          {step === 1 && renderStep1()}
          {step === 2 && renderStep2()}
          {step === 3 && renderStep3()}
          {step === 4 && renderStep4()}
        </CardContent>
      </Card>
    </div>
  );
}