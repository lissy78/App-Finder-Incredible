import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { MapPin, Zap, Target, Navigation, Search, Globe, HelpCircle } from 'lucide-react';
import { useState } from 'react';
import { GeolocationHelp } from './GeolocationHelp';

export function GeoInfoPanel() {
  const [showHelp, setShowHelp] = useState(false);

  const features = [
    {
      icon: <Search className="w-5 h-5 text-blue-600" />,
      title: "Búsqueda Inteligente",
      description: "Escribe cualquier dirección y obtén coordenadas exactas automáticamente",
      badge: "IA"
    },
    {
      icon: <Target className="w-5 h-5 text-green-600" />,
      title: "Precisión GPS",
      description: "Ubicaciones exactas con precisión de metros en Yumbo, Valle del Cauca",
      badge: "Alta Precisión"
    },
    {
      icon: <Navigation className="w-5 h-5 text-purple-600" />,
      title: "Tu Ubicación",
      description: "Detectamos tu posición actual para mostrarte misiones cercanas",
      badge: "Tiempo Real"
    },
    {
      icon: <Globe className="w-5 h-5 text-orange-600" />,
      title: "Cobertura Total",
      description: "Mapa completo de Yumbo con todas las misiones disponibles",
      badge: "100% Cubierto"
    },
    {
      icon: <Zap className="w-5 h-5 text-red-600" />,
      title: "Actualizaciones",
      description: "Las misiones se actualizan en tiempo real mientras navegas",
      badge: "En Vivo"
    },
    {
      icon: <MapPin className="w-5 h-5 text-indigo-600" />,
      title: "Distancias",
      description: "Calcula automáticamente qué tan lejos está cada misión de ti",
      badge: "Auto"
    }
  ];

  return (
    <>
      <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-blue-50">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <Globe className="w-4 h-4 text-white" />
              </div>
              <span>Sistema de Geolocalización Avanzado</span>
              <Badge variant="outline" className="bg-green-100 text-green-800">
                🚀 Revolucionario
              </Badge>
            </CardTitle>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowHelp(!showHelp)}
              className="flex items-center space-x-1"
            >
              <HelpCircle className="w-4 h-4" />
              <span>{showHelp ? 'Ocultar' : 'Ayuda GPS'}</span>
            </Button>
          </div>
        </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="text-sm text-gray-600 bg-white/50 p-3 rounded-lg border border-white/50">
          <p className="mb-2">
            <strong>GoodImpact</strong> utiliza la tecnología de geolocalización más avanzada 
            para conectar héroes de bondad en Yumbo, Valle del Cauca, Colombia 🇨🇴
          </p>
          <p className="text-xs text-gray-500">
            Tan fácil de usar que hasta un niño de 7 años puede encontrar y crear misiones
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {features.map((feature, index) => (
            <div key={index} className="bg-white/70 p-3 rounded-lg border border-white/50 hover:bg-white/90 transition-all duration-200">
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  {feature.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="text-sm font-medium text-gray-900">{feature.title}</h4>
                    <Badge variant="secondary" className="text-xs">
                      {feature.badge}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Estadísticas impresionantes */}
        <div className="bg-white/70 p-4 rounded-lg border border-white/50">
          <div className="text-center space-y-2">
            <h4 className="text-sm font-medium text-gray-900">🎯 Tecnología de Última Generación</h4>
            <div className="grid grid-cols-3 gap-4 text-xs">
              <div className="text-center">
                <div className="font-bold text-blue-600 text-lg">±3m</div>
                <div className="text-gray-600">Precisión GPS</div>
              </div>
              <div className="text-center">
                <div className="font-bold text-green-600 text-lg">&lt;500ms</div>
                <div className="text-gray-600">Tiempo de búsqueda</div>
              </div>
              <div className="text-center">
                <div className="font-bold text-purple-600 text-lg">25km</div>
                <div className="text-gray-600">Radio de cobertura</div>
              </div>
            </div>
          </div>
        </div>

        {/* Instrucciones simples */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
          <div className="flex items-start space-x-2">
            <div className="w-5 h-5 flex items-center justify-center bg-yellow-500 rounded-full flex-shrink-0">
              <span className="text-white text-xs">💡</span>
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-medium text-yellow-800 mb-1">¿Cómo funciona?</h4>
              <ol className="text-xs text-yellow-700 space-y-1 list-decimal list-inside">
                <li>Escribe cualquier dirección de Yumbo en el buscador</li>
                <li>Selecciona la ubicación exacta de las sugerencias</li>
                <li>¡Listo! Las coordenadas se obtienen automáticamente</li>
              </ol>
            </div>
          </div>
        </div>

        {/* Footer con ubicación */}
        <div className="text-center text-xs text-gray-500 pt-2 border-t border-white/50">
          📍 Especializado en <strong>Yumbo, Valle del Cauca, Colombia</strong>
          <br />
          🌎 Coordenadas base: 3.5836°N, -76.4951°W
        </div>
      </CardContent>
    </Card>

      {/* Panel de ayuda expandible */}
      {showHelp && (
        <div className="mt-4 animate-in slide-in-from-top-4">
          <GeolocationHelp />
        </div>
      )}
    </>
  );
}