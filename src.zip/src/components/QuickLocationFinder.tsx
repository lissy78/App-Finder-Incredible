import { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { MapPin, Search, Navigation, Zap, Target } from 'lucide-react';
import { LocationSearch } from './LocationSearch';

interface QuickLocationFinderProps {
  onLocationFound?: (location: {
    lat: number;
    lng: number;
    address: string;
  }) => void;
  className?: string;
  compact?: boolean;
}

export function QuickLocationFinder({ 
  onLocationFound, 
  className = "", 
  compact = false 
}: QuickLocationFinderProps) {
  const [selectedLocation, setSelectedLocation] = useState<{
    lat: number;
    lng: number;
    address: string;
  } | null>(null);
  const [isExpanded, setIsExpanded] = useState(!compact);

  // Ubicaciones rápidas predefinidas en Yumbo
  const quickLocations = [
    { 
      name: "Centro de Yumbo", 
      address: "Centro, Yumbo, Valle del Cauca", 
      lat: 3.5836, 
      lng: -76.4951,
      icon: "🏛️"
    },
    { 
      name: "Parque Central", 
      address: "Parque Central, Yumbo, Valle del Cauca", 
      lat: 3.5841, 
      lng: -76.4955,
      icon: "🌳"
    },
    { 
      name: "Plaza Principal", 
      address: "Plaza Principal, Yumbo, Valle del Cauca", 
      lat: 3.5830, 
      lng: -76.4948,
      icon: "🏛️"
    },
    { 
      name: "Terminal de Transporte", 
      address: "Terminal de Transporte, Yumbo, Valle del Cauca", 
      lat: 3.5820, 
      lng: -76.4960,
      icon: "🚌"
    },
    { 
      name: "Zona Industrial", 
      address: "Zona Industrial, Yumbo, Valle del Cauca", 
      lat: 3.5900, 
      lng: -76.5000,
      icon: "🏭"
    },
    { 
      name: "Hospital Local", 
      address: "Hospital, Yumbo, Valle del Cauca", 
      lat: 3.5825, 
      lng: -76.4940,
      icon: "🏥"
    }
  ];

  const handleLocationSelect = (location: {lat: number, lng: number, address: string}) => {
    setSelectedLocation(location);
    onLocationFound?.(location);
  };

  const handleQuickLocation = (quickLoc: typeof quickLocations[0]) => {
    const location = {
      lat: quickLoc.lat,
      lng: quickLoc.lng,
      address: quickLoc.address
    };
    handleLocationSelect(location);
  };

  if (compact && !isExpanded) {
    return (
      <div className={`${className}`}>
        <Button
          variant="outline"
          onClick={() => setIsExpanded(true)}
          className="flex items-center space-x-2 hover:bg-blue-50 hover:border-blue-300"
        >
          <Search className="w-4 h-4" />
          <span>Buscar ubicación</span>
          <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
            Geo AI
          </Badge>
        </Button>
      </div>
    );
  }

  return (
    <Card className={`border-2 border-blue-200 shadow-lg ${className}`}>
      <CardContent className="p-4 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Target className="w-5 h-5 text-blue-600" />
            <h3 className="font-semibold text-gray-900">Encontrar Ubicación</h3>
            <Badge variant="outline" className="bg-blue-100 text-blue-800 text-xs">
              🤖 IA Geográfica
            </Badge>
          </div>
          {compact && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsExpanded(false)}
              className="text-gray-500 hover:text-gray-700"
            >
              ✕
            </Button>
          )}
        </div>

        {/* Búsqueda principal */}
        <div className="space-y-3">
          <LocationSearch
            onLocationSelect={handleLocationSelect}
            placeholder="Escribe cualquier dirección en Yumbo..."
            focusOnYumbo={true}
          />
          
          {selectedLocation && (
            <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-green-800">Ubicación encontrada</p>
                  <p className="text-xs text-green-700 mt-1 break-words">{selectedLocation.address}</p>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-green-600">
                    <span>📍 {selectedLocation.lat.toFixed(6)}</span>
                    <span>📍 {selectedLocation.lng.toFixed(6)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Ubicaciones rápidas */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-orange-600" />
            <span className="text-sm font-medium text-gray-700">Ubicaciones populares</span>
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            {quickLocations.map((location, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => handleQuickLocation(location)}
                className="justify-start text-left h-auto py-2 px-3 hover:bg-blue-50 hover:border-blue-300"
              >
                <div className="flex items-center space-x-2 w-full">
                  <span className="text-lg">{location.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-gray-900 truncate">
                      {location.name}
                    </div>
                    <div className="text-xs text-gray-500 truncate">
                      {location.address.split(',')[0]}
                    </div>
                  </div>
                </div>
              </Button>
            ))}
          </div>
        </div>

        {/* Acciones adicionales */}
        <div className="flex space-x-2 pt-3 border-t border-gray-200">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              if (!navigator.geolocation) {
                console.log('Geolocation not available, using Yumbo center');
                const yumboLocation = {
                  lat: 3.5836,
                  lng: -76.4951,
                  address: "Yumbo, Valle del Cauca, Colombia (por defecto)"
                };
                handleLocationSelect(yumboLocation);
                return;
              }

              navigator.geolocation.getCurrentPosition(
                (position) => {
                  const location = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                    address: `📍 Tu ubicación GPS (${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)})`
                  };
                  console.log('✅ QuickLocationFinder - GPS location obtained successfully:', location);
                  handleLocationSelect(location);
                },
                (error) => {
                  let errorMessage = 'Error de geolocalización';
                  let errorCode = 'UNKNOWN';
                  
                  switch (error.code) {
                    case 1: // PERMISSION_DENIED
                      errorCode = 'PERMISSION_DENIED';
                      errorMessage = 'Permiso denegado';
                      break;
                    case 2: // POSITION_UNAVAILABLE
                      errorCode = 'POSITION_UNAVAILABLE';
                      errorMessage = 'GPS no disponible';
                      break;
                    case 3: // TIMEOUT
                      errorCode = 'TIMEOUT';
                      errorMessage = 'Tiempo agotado';
                      break;
                    default:
                      errorMessage = error.message || 'Error desconocido';
                  }
                  
                  console.log('📍 QuickLocationFinder - Geolocation error:', {
                    errorCode: errorCode,
                    errorType: error.code === 1 ? 'PERMISSION_DENIED' : error.code === 2 ? 'POSITION_UNAVAILABLE' : error.code === 3 ? 'TIMEOUT' : 'UNKNOWN',
                    originalCode: error.code,
                    originalMessage: error.message,
                    userMessage: errorMessage,
                    fallbackApplied: 'Yumbo center',
                    timestamp: new Date().toISOString()
                  });
                  
                  // Fallback a Yumbo en caso de error
                  const yumboLocation = {
                    lat: 3.5836,
                    lng: -76.4951,
                    address: `⚠️ Yumbo, Valle del Cauca (${errorMessage})`
                  };
                  handleLocationSelect(yumboLocation);
                },
                {
                  enableHighAccuracy: false,
                  timeout: 10000,
                  maximumAge: 300000
                }
              );
            }}
            className="flex items-center space-x-1 flex-1"
          >
            <Navigation className="w-3 h-3" />
            <span className="text-xs">Mi ubicación</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              const yumeboCenter = {
                lat: 3.5836,
                lng: -76.4951,
                address: "Centro de Yumbo, Valle del Cauca"
              };
              handleLocationSelect(yumeboCenter);
            }}
            className="flex items-center space-x-1 flex-1"
          >
            <MapPin className="w-3 h-3" />
            <span className="text-xs">Centro Yumbo</span>
          </Button>
        </div>

        {/* Información adicional */}
        <div className="text-xs text-gray-500 bg-gray-50 rounded-lg p-3">
          <div className="flex items-center space-x-1 mb-1">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
            <span className="font-medium">Geolocalización de alta precisión</span>
          </div>
          <p>
            Nuestro sistema utiliza coordenadas GPS exactas para encontrar ubicaciones 
            con precisión de metros en Yumbo, Valle del Cauca.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}