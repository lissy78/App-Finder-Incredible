import { useState } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MapPin, Navigation, Loader2, Check, AlertCircle } from 'lucide-react';

interface Location {
  lat: number;
  lng: number;
  address: string;
  neighborhood?: string;
  city?: string;
  country?: string;
}

interface ReverseGeocoderProps {
  onAddressFound: (location: Location) => void;
  className?: string;
}

export function ReverseGeocoder({ onAddressFound, className = '' }: ReverseGeocoderProps) {
  const [loading, setLoading] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<Location | null>(null);
  const [error, setError] = useState<string | null>(null);

  const reverseGeocode = async (lat: number, lng: number): Promise<Location> => {
    // Usar Nominatim de OpenStreetMap para geocodificación inversa gratuita
    const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`;
    
    try {
      const response = await fetch(url, {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'GoodImpact-App'
        }
      });

      if (!response.ok) {
        throw new Error('Geocoding failed');
      }

      const data = await response.json();
      
      // Construir dirección detallada
      const address = data.address;
      let fullAddress = '';
      
      if (address.road) fullAddress += address.road;
      if (address.house_number) fullAddress += ' #' + address.house_number;
      if (address.neighbourhood) fullAddress += ', ' + address.neighbourhood;
      if (address.suburb) fullAddress += ', ' + address.suburb;
      if (address.city || address.town || address.village) {
        fullAddress += ', ' + (address.city || address.town || address.village);
      }
      if (address.state) fullAddress += ', ' + address.state;
      if (address.country) fullAddress += ', ' + address.country;

      // Si no hay dirección detallada, usar display_name
      if (!fullAddress) {
        fullAddress = data.display_name;
      }

      return {
        lat,
        lng,
        address: fullAddress || 'Dirección no disponible',
        neighborhood: address.neighbourhood || address.suburb,
        city: address.city || address.town || address.village || 'Yumbo',
        country: address.country || 'Colombia'
      };
    } catch (error) {
      console.error('Reverse geocoding error:', error);
      throw error;
    }
  };

  const getCurrentLocationAddress = async () => {
    setLoading(true);
    setError(null);

    try {
      if (!navigator.geolocation) {
        throw new Error('La geolocalización no está disponible en tu navegador');
      }

      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          resolve, 
          (error) => {
            // Crear un error más descriptivo
            const geoError = new Error();
            (geoError as any).code = error.code;
            (geoError as any).message = error.message;
            reject(geoError);
          }, 
          {
            enableHighAccuracy: false, // Cambiar a false para mejor compatibilidad
            timeout: 15000,
            maximumAge: 30000
          }
        );
      });

      const { latitude, longitude } = position.coords;

      // Obtener dirección de las coordenadas
      const location = await reverseGeocode(latitude, longitude);
      
      setCurrentLocation(location);
      onAddressFound(location);
      
    } catch (err: any) {
      let errorMessage = 'No se pudo obtener tu ubicación';
      let errorCode = 'UNKNOWN';
      
      // Manejar diferentes tipos de errores de geolocalización
      if (err && typeof err === 'object' && 'code' in err) {
        switch (err.code) {
          case 1: // PERMISSION_DENIED
            errorCode = 'PERMISSION_DENIED';
            errorMessage = '📍 Permiso de ubicación denegado. Por favor, haz clic en el ícono de candado junto a la URL del navegador y permite el acceso a tu ubicación.';
            break;
          case 2: // POSITION_UNAVAILABLE
            errorCode = 'POSITION_UNAVAILABLE';
            errorMessage = '🛰️ Tu ubicación GPS no está disponible en este momento. Asegúrate de tener GPS activado y estar en un lugar con buena señal.';
            break;
          case 3: // TIMEOUT
            errorCode = 'TIMEOUT';
            errorMessage = '⏱️ El GPS está tardando demasiado en responder. Verifica tu señal e intenta nuevamente.';
            break;
          default:
            errorCode = 'UNKNOWN';
            errorMessage = `⚠️ ${err.message || 'Error desconocido al obtener ubicación.'}`;
        }
      } else if (err && err.message) {
        errorMessage = `⚠️ ${err.message}`;
      }
      
      setError(errorMessage);
      console.log('📍 ReverseGeocoder - Geolocation error:', {
        errorCode: errorCode,
        errorType: err?.code === 1 ? 'PERMISSION_DENIED' : err?.code === 2 ? 'POSITION_UNAVAILABLE' : err?.code === 3 ? 'TIMEOUT' : 'UNKNOWN',
        originalError: err,
        originalCode: err?.code,
        originalMessage: err?.message,
        userFriendlyMessage: errorMessage,
        fallbackApplied: 'Yumbo, Valle del Cauca',
        timestamp: new Date().toISOString()
      });
      
      // Fallback a Yumbo si falla
      const yumboLocation: Location = {
        lat: 3.5836,
        lng: -76.4951,
        address: 'Yumbo, Valle del Cauca, Colombia (ubicación predeterminada)',
        city: 'Yumbo',
        country: 'Colombia'
      };
      setCurrentLocation(yumboLocation);
      onAddressFound(yumboLocation);
    }

    setLoading(false);
  };

  return (
    <div className={className}>
      {!currentLocation ? (
        <Button
          onClick={getCurrentLocationAddress}
          disabled={loading}
          variant="outline"
          className="w-full border-2 border-blue-300 hover:border-blue-500 hover:bg-blue-50"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Obteniendo dirección exacta...
            </>
          ) : (
            <>
              <Navigation className="w-4 h-4 mr-2" />
              📍 Usar mi ubicación actual (GPS preciso)
            </>
          )}
        </Button>
      ) : (
        <Card className="border-2 border-green-200 bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Check className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-green-900 mb-1">
                  ✅ Dirección detectada con precisión GPS
                </h4>
                <p className="text-sm text-green-800 mb-2">
                  {currentLocation.address}
                </p>
                <div className="flex flex-wrap gap-2">
                  {currentLocation.neighborhood && (
                    <Badge variant="outline" className="bg-white text-green-700">
                      🏘️ {currentLocation.neighborhood}
                    </Badge>
                  )}
                  {currentLocation.city && (
                    <Badge variant="outline" className="bg-white text-green-700">
                      🏙️ {currentLocation.city}
                    </Badge>
                  )}
                  <Badge variant="outline" className="bg-white text-green-700 text-xs">
                    📍 {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}
                  </Badge>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setCurrentLocation(null);
                    setError(null);
                  }}
                  className="mt-2 text-green-700 hover:text-green-800"
                >
                  Cambiar ubicación
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {error && (
        <Card className="border-2 border-yellow-200 bg-yellow-50 mt-3">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm text-yellow-800">{error}</p>
                {currentLocation && (
                  <p className="text-xs text-yellow-700 mt-1">
                    Usando ubicación predeterminada: {currentLocation.address}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
