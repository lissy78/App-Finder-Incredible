import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Download, 
  Share2, 
  Verified, 
  Star,
  MapPin,
  Target,
  CheckCircle,
  Award,
  Sparkles,
  Eye,
  Heart,
  TrendingUp
} from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface PersonalizedResumeProps {
  userId: string;
  viewerId?: string; // ID del cliente que está viendo el currículum
  viewerName?: string; // Nombre del cliente
}

interface CompletedMission {
  id: string;
  title: string;
  category: string;
  difficulty: string;
  completedAt: string;
  verifiedBy: string;
  rating: number;
  paymentReceived: string;
  testimonial?: string;
  skillsLearned: string[];
  location: string;
  duration: string;
}

export function PersonalizedResume({ userId, viewerId, viewerName }: PersonalizedResumeProps) {
  const [userData, setUserData] = useState<any>(null);
  const [completedMissions, setCompletedMissions] = useState<CompletedMission[]>([]);
  const [relevantMissions, setRelevantMissions] = useState<CompletedMission[]>([]);
  const [loading, setLoading] = useState(true);
  const [personalizedMessage, setPersonalizedMessage] = useState('');

  useEffect(() => {
    loadPersonalizedResume();
  }, [userId, viewerId]);

  const loadPersonalizedResume = async () => {
    setLoading(true);
    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-34f10c60/user/${userId}/resume/personalized`;
      const params = new URLSearchParams();
      
      if (viewerId) {
        params.append('viewerId', viewerId);
      }

      const response = await fetch(`${url}?${params.toString()}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          setUserData(data.userData);
          setCompletedMissions(data.completedMissions || []);
          setRelevantMissions(data.relevantMissions || []);
          setPersonalizedMessage(data.personalizedMessage || '');
        }
      }
    } catch (error) {
      console.error('Error loading personalized resume:', error);
    }
    setLoading(false);
  };

  const shareResume = async () => {
    const shareText = viewerName 
      ? `Mira el currículum personalizado de ${userData?.name} para ${viewerName} en GoodImpact`
      : `Mira el currículum de ${userData?.name} en GoodImpact`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Currículum GoodImpact - ${userData?.name}`,
          text: shareText,
          url: window.location.href
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      navigator.clipboard.writeText(`${shareText} - ${window.location.href}`);
      alert('¡Enlace copiado al portapapeles!');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!userData) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">No se pudo cargar el currículum</p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {/* Mensaje personalizado para el cliente */}
      {viewerName && personalizedMessage && (
        <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-start space-x-3">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg text-blue-900 mb-2">
                  💼 Currículum personalizado para {viewerName}
                </h3>
                <p className="text-blue-800">{personalizedMessage}</p>
                <Badge className="mt-3 bg-blue-600 text-white">
                  <Eye className="w-3 h-3 mr-1" />
                  Vista personalizada
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Header del currículum */}
      <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <CardContent className="p-8">
          <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
            <Avatar className="w-24 h-24 border-4 border-white">
              <AvatarImage src={userData?.avatar} />
              <AvatarFallback className="text-2xl bg-white text-blue-600">
                {userData?.name?.split(' ').map((n: string) => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-3xl font-bold flex items-center justify-center md:justify-start">
                {userData?.name}
                <Verified className="w-6 h-6 ml-2 text-yellow-300" />
              </h1>
              <p className="text-xl opacity-90">{userData?.location?.address}</p>
              
              <div className="flex flex-wrap justify-center md:justify-start gap-2 mt-4">
                <Badge className="bg-white/20 text-white border-white/30">
                  ⭐ Nivel {userData?.goodnessLevel}
                </Badge>
                <Badge className="bg-white/20 text-white border-white/30">
                  🎯 {userData?.totalMissions || completedMissions.length} misiones
                </Badge>
                <Badge className="bg-white/20 text-white border-white/30">
                  🏆 100% Verificado
                </Badge>
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button variant="secondary" onClick={shareResume}>
                <Share2 className="w-4 h-4 mr-2" />
                Compartir
              </Button>
              <Button variant="secondary">
                <Download className="w-4 h-4 mr-2" />
                Descargar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Misiones relevantes para este cliente */}
      {viewerId && relevantMissions.length > 0 && (
        <Card className="border-2 border-purple-200">
          <CardHeader className="bg-purple-50">
            <CardTitle className="flex items-center">
              <Sparkles className="w-6 h-6 mr-2 text-purple-600" />
              Experiencia Relevante para Ti
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              {relevantMissions.map((mission) => (
                <Card key={mission.id} className="border-l-4 border-l-purple-500 bg-purple-50/50">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-bold flex items-center mb-2">
                          {mission.title}
                          <CheckCircle className="w-4 h-4 ml-2 text-green-600" />
                        </h4>
                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge variant="secondary">{mission.category}</Badge>
                          <Badge variant="outline">{mission.difficulty}</Badge>
                          {mission.skillsLearned.slice(0, 2).map((skill) => (
                            <Badge key={skill} variant="outline" className="bg-blue-50 text-blue-700">
                              ⚡ {skill}
                            </Badge>
                          ))}
                        </div>
                        {mission.testimonial && (
                          <div className="bg-white p-3 rounded border-l-2 border-l-blue-500">
                            <p className="italic text-sm text-gray-700">"{mission.testimonial}"</p>
                            <p className="text-xs text-gray-600 mt-1 font-medium">
                              - {mission.verifiedBy} <Verified className="w-3 h-3 inline text-blue-600" />
                            </p>
                          </div>
                        )}
                      </div>
                      <div className="flex items-center space-x-1 ml-4">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-4 h-4 ${i < mission.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="misiones" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="misiones">✅ Todas las Misiones</TabsTrigger>
          <TabsTrigger value="habilidades">⚡ Habilidades</TabsTrigger>
          <TabsTrigger value="estadisticas">📊 Estadísticas</TabsTrigger>
        </TabsList>

        <TabsContent value="misiones">
          <div className="space-y-4">
            {completedMissions.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Target className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    Aún no hay misiones completadas
                  </h3>
                  <p className="text-gray-600">
                    Este héroe está comenzando su viaje en GoodImpact
                  </p>
                </CardContent>
              </Card>
            ) : (
              completedMissions.map((mission) => (
                <Card key={mission.id} className="border-l-4 border-l-green-500">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-start justify-between space-y-4 md:space-y-0">
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="text-xl font-bold flex items-center">
                              {mission.title}
                              <CheckCircle className="w-5 h-5 ml-2 text-green-600" />
                            </h3>
                            <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                              <span className="flex items-center">
                                📅 {new Date(mission.completedAt).toLocaleDateString('es')}
                              </span>
                              <span className="flex items-center">
                                <MapPin className="w-4 h-4 mr-1" />
                                {mission.location}
                              </span>
                            </div>
                          </div>
                          
                          <div className="text-right">
                            <div className="flex items-center space-x-1 mb-1">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`w-4 h-4 ${i < mission.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                                />
                              ))}
                            </div>
                            <Badge variant="outline" className="bg-green-50 text-green-700">
                              {mission.paymentReceived}
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge variant="secondary">{mission.category}</Badge>
                          <Badge variant="outline">{mission.difficulty}</Badge>
                          {mission.skillsLearned.map((skill) => (
                            <Badge key={skill} variant="outline" className="bg-blue-50 text-blue-700">
                              ⚡ {skill}
                            </Badge>
                          ))}
                        </div>
                        
                        {mission.testimonial && (
                          <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-l-blue-500">
                            <p className="italic text-gray-700">"{mission.testimonial}"</p>
                            <p className="text-sm text-gray-600 mt-2 font-medium">
                              - {mission.verifiedBy} <Verified className="w-4 h-4 inline text-blue-600" />
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="habilidades">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>💪 Habilidades Demostradas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Array.from(new Set(completedMissions.flatMap(m => m.skillsLearned))).slice(0, 8).map((skill, idx) => (
                    <div key={idx} className="flex items-center justify-between">
                      <span className="text-sm">{skill}</span>
                      <Badge variant="outline">
                        {completedMissions.filter(m => m.skillsLearned.includes(skill)).length} misiones
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>🏷️ Categorías de Experiencia</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Array.from(new Set(completedMissions.map(m => m.category))).map((category, idx) => (
                    <div key={idx} className="flex items-center justify-between">
                      <span className="text-sm">{category}</span>
                      <Badge variant="secondary">
                        {completedMissions.filter(m => m.category === category).length} completadas
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="estadisticas">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="text-center">
              <CardContent className="p-6">
                <Target className="w-8 h-8 mx-auto text-blue-600 mb-2" />
                <div className="text-3xl font-bold text-blue-600">{completedMissions.length}</div>
                <p className="text-gray-600">Misiones Completadas</p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <Star className="w-8 h-8 mx-auto text-yellow-600 mb-2" />
                <div className="text-3xl font-bold text-yellow-600">
                  {completedMissions.length > 0 
                    ? (completedMissions.reduce((sum, m) => sum + m.rating, 0) / completedMissions.length).toFixed(1)
                    : 0}
                </div>
                <p className="text-gray-600">Calificación Promedio</p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <Award className="w-8 h-8 mx-auto text-purple-600 mb-2" />
                <div className="text-3xl font-bold text-purple-600">
                  {completedMissions.filter(m => m.rating === 5).length}
                </div>
                <p className="text-gray-600">5 Estrellas</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
