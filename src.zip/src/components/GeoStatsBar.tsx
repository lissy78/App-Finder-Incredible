import { useState, useEffect } from 'react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { MapPin, Zap, Users, Clock, Target, Navigation } from 'lucide-react';

interface GeoStatsBarProps {
  missions: Array<{
    id: string;
    location: {
      lat: number;
      lng: number;
      address: string;
    };
    participants: number;
    maxParticipants: number;
    isUrgent?: boolean;
  }>;
  userLocation?: { lat: number; lng: number } | null;
}

export function GeoStatsBar({ missions, userLocation }: GeoStatsBarProps) {
  const [nearbyMissions, setNearbyMissions] = useState(0);
  const [avgDistance, setAvgDistance] = useState(0);
  const [closestMission, setClosestMission] = useState<number | null>(null);

  // Calcular distancia entre dos puntos (en km)
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
    const R = 6371; // Radio de la Tierra en km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  useEffect(() => {
    if (!userLocation || missions.length === 0) {
      setNearbyMissions(0);
      setAvgDistance(0);
      setClosestMission(null);
      return;
    }

    const distances = missions.map(mission => 
      calculateDistance(
        userLocation.lat, 
        userLocation.lng, 
        mission.location.lat, 
        mission.location.lng
      )
    );

    // Misiones cercanas (menos de 5 km)
    const nearby = distances.filter(distance => distance <= 5).length;
    setNearbyMissions(nearby);

    // Distancia promedio
    const avg = distances.reduce((sum, distance) => sum + distance, 0) / distances.length;
    setAvgDistance(avg);

    // Misión más cercana
    const closest = Math.min(...distances);
    setClosestMission(closest);
  }, [missions, userLocation]);

  const urgentMissions = missions.filter(m => m.isUrgent).length;
  const totalParticipants = missions.reduce((sum, m) => sum + m.participants, 0);
  const availableSpots = missions.reduce((sum, m) => sum + (m.maxParticipants - m.participants), 0);

  return (
    <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-green-50">
      <CardContent className="p-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          {/* Estadísticas de ubicación */}
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-blue-600" />
              <div className="text-sm">
                <div className="font-semibold text-gray-900">{missions.length}</div>
                <div className="text-gray-600 text-xs">Misiones activas</div>
              </div>
            </div>

            {userLocation && (
              <>
                <div className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-green-600" />
                  <div className="text-sm">
                    <div className="font-semibold text-gray-900">{nearbyMissions}</div>
                    <div className="text-gray-600 text-xs">Cerca de ti (&lt;5km)</div>
                  </div>
                </div>

                {closestMission !== null && (
                  <div className="flex items-center space-x-2">
                    <Navigation className="w-5 h-5 text-purple-600" />
                    <div className="text-sm">
                      <div className="font-semibold text-gray-900">{closestMission.toFixed(1)} km</div>
                      <div className="text-gray-600 text-xs">Más cercana</div>
                    </div>
                  </div>
                )}

                <div className="flex items-center space-x-2">
                  <div className="w-5 h-5 flex items-center justify-center">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse" />
                  </div>
                  <div className="text-sm">
                    <div className="font-semibold text-gray-900">{avgDistance.toFixed(1)} km</div>
                    <div className="text-gray-600 text-xs">Distancia promedio</div>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Estadísticas de participación */}
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-indigo-600" />
              <div className="text-sm">
                <div className="font-semibold text-gray-900">{totalParticipants}</div>
                <div className="text-gray-600 text-xs">Participando</div>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 flex items-center justify-center">
                <div className="w-3 h-3 bg-green-500 rounded-full" />
              </div>
              <div className="text-sm">
                <div className="font-semibold text-gray-900">{availableSpots}</div>
                <div className="text-gray-600 text-xs">Cupos disponibles</div>
              </div>
            </div>

            {urgentMissions > 0 && (
              <div className="flex items-center space-x-2">
                <Zap className="w-5 h-5 text-red-600 animate-pulse" />
                <div className="text-sm">
                  <div className="font-semibold text-red-600">{urgentMissions}</div>
                  <div className="text-gray-600 text-xs">Urgentes</div>
                </div>
              </div>
            )}
          </div>

          {/* Badges de estado */}
          <div className="flex items-center space-x-2">
            {userLocation ? (
              <Badge variant="outline" className="text-green-600 border-green-600 bg-green-50">
                🟢 Geolocalizado
              </Badge>
            ) : (
              <Badge variant="outline" className="text-yellow-600 border-yellow-600 bg-yellow-50">
                📍 Ubicando...
              </Badge>
            )}
            
            <Badge variant="outline" className="text-blue-600 border-blue-600 bg-blue-50">
              🗺️ Yumbo, Valle del Cauca
            </Badge>

            {missions.length > 0 && (
              <Badge variant="outline" className="text-purple-600 border-purple-600 bg-purple-50 animate-pulse">
                ⚡ Actualizado
              </Badge>
            )}
          </div>
        </div>

        {/* Barra de progreso de área cubierta */}
        {userLocation && (
          <div className="mt-4 pt-3 border-t border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Cobertura del área</span>
              <span className="text-sm text-gray-600">
                Radio de {Math.max(5, Math.ceil(avgDistance))} km desde tu ubicación
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-500"
                style={{ 
                  width: `${Math.min(100, (nearbyMissions / Math.max(missions.length, 1)) * 100)}%` 
                }}
              />
            </div>
            <div className="flex justify-between text-xs text-gray-600 mt-1">
              <span>Misiones locales: {nearbyMissions}</span>
              <span>Total disponible: {missions.length}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}