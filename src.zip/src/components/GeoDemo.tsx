import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MapPin, Target, Search, Zap, CheckCircle } from 'lucide-react';
import { LocationSearch } from './LocationSearch';

export function GeoDemo() {
  const [demoLocation, setDemoLocation] = useState<{
    lat: number;
    lng: number;
    address: string;
  } | null>(null);
  const [showDemo, setShowDemo] = useState(false);

  const demoAddresses = [
    "Parque Central Yumbo",
    "Centro Comercial Yumbo Plaza",
    "Terminal de Transporte Yumbo",
    "Zona Industrial Acopi",
    "Institución Educativa José María Córdoba",
    "Casa de la Cultura Yumbo"
  ];

  const searchDemo = async (address: string) => {
    // Simular búsqueda para demo
    const mockResults = {
      "Parque Central Yumbo": { lat: 3.583600, lng: -76.495100, address: "Parque Central, Calle 13 #14-15, Yumbo, Valle del Cauca" },
      "Centro Comercial Yumbo Plaza": { lat: 3.582023, lng: -76.496032, address: "Carrera 14 #12-45, Centro Comercial Yumbo Plaza, Yumbo, Valle del Cauca" },
      "Terminal de Transporte Yumbo": { lat: 3.582156, lng: -76.493345, address: "Terminal de Transporte, Carrera 13 #8-25, Yumbo, Valle del Cauca" },
      "Zona Industrial Acopi": { lat: 3.590012, lng: -76.500025, address: "Zona Industrial Acopi, Km 1 Vía Cali-Yumbo, Yumbo, Valle del Cauca" },
      "Institución Educativa José María Córdoba": { lat: 3.584567, lng: -76.494123, address: "Institución Educativa José María Córdoba, Yumbo, Valle del Cauca" },
      "Casa de la Cultura Yumbo": { lat: 3.583891, lng: -76.495678, address: "Casa de la Cultura, Centro, Yumbo, Valle del Cauca" }
    };

    const result = mockResults[address as keyof typeof mockResults];
    if (result) {
      setDemoLocation(result);
    }
  };

  if (!showDemo) {
    return (
      <Card className="border-2 border-dashed border-green-300 hover:border-green-500 transition-all duration-300">
        <CardContent className="p-6 text-center">
          <div className="space-y-4">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <Target className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="font-bold text-gray-900">¡Prueba la Geolocalización!</h3>
            <p className="text-gray-600 text-sm max-w-md mx-auto">
              Experimenta cómo encontrar ubicaciones exactas en Yumbo con solo escribir una dirección
            </p>
            <Button 
              onClick={() => setShowDemo(true)}
              className="bg-green-600 hover:bg-green-700"
            >
              <Zap className="w-4 h-4 mr-2" />
              Probar Ahora
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-blue-50">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Target className="w-5 h-5 text-green-600" />
          <span>Demo de Geolocalización</span>
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            En Vivo
          </Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Búsqueda en vivo */}
        <div className="space-y-3">
          <h4 className="font-medium text-gray-900">🔍 Búsqueda Inteligente</h4>
          <LocationSearch
            onLocationSelect={(location) => setDemoLocation(location)}
            placeholder="Prueba escribir una dirección de Yumbo..."
            focusOnYumbo={true}
          />
        </div>

        {/* Resultado de la búsqueda */}
        {demoLocation && (
          <div className="p-4 bg-white border border-green-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <h5 className="font-medium text-green-800">¡Ubicación encontrada!</h5>
                <p className="text-sm text-gray-700 mt-1">{demoLocation.address}</p>
                <div className="grid grid-cols-2 gap-4 mt-3 text-xs text-gray-600">
                  <div className="bg-gray-50 p-2 rounded">
                    <span className="font-medium">Latitud:</span> {demoLocation.lat.toFixed(6)}
                  </div>
                  <div className="bg-gray-50 p-2 rounded">
                    <span className="font-medium">Longitud:</span> {demoLocation.lng.toFixed(6)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Búsquedas rápidas de ejemplo */}
        <div className="space-y-3">
          <h4 className="font-medium text-gray-900">⚡ Pruebas Rápidas</h4>
          <div className="grid grid-cols-2 gap-2">
            {demoAddresses.map((address, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => searchDemo(address)}
                className="text-left h-auto p-3 hover:bg-green-50 hover:border-green-300"
              >
                <div className="w-full">
                  <div className="text-xs font-medium text-gray-900 truncate">
                    {address}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Click para buscar
                  </div>
                </div>
              </Button>
            ))}
          </div>
        </div>

        {/* Estadísticas del demo */}
        <div className="bg-white/70 p-4 rounded-lg border border-green-200">
          <h4 className="font-medium text-gray-900 mb-2">📊 Capacidades del Sistema</h4>
          <div className="grid grid-cols-3 gap-4 text-xs text-center">
            <div>
              <div className="font-bold text-green-600 text-lg">±3m</div>
              <div className="text-gray-600">Precisión GPS</div>
            </div>
            <div>
              <div className="font-bold text-blue-600 text-lg">&lt;500ms</div>
              <div className="text-gray-600">Tiempo respuesta</div>
            </div>
            <div>
              <div className="font-bold text-purple-600 text-lg">25km</div>
              <div className="text-gray-600">Radio cobertura</div>
            </div>
          </div>
        </div>

        {/* Botón para cerrar demo */}
        <div className="text-center">
          <Button 
            variant="outline" 
            onClick={() => setShowDemo(false)}
            className="text-gray-600 hover:text-gray-800"
          >
            Cerrar Demo
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}