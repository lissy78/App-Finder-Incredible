import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { Slider } from './ui/slider';
import { Switch } from './ui/switch';
import { 
  Plus, 
  MapPin, 
  Clock, 
  DollarSign, 
  Users, 
  Star,
  Gift,
  Handshake,
  Coins,
  Heart,
  Sparkles,
  Zap
} from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { LocationSearch } from './LocationSearch';
import { ReverseGeocoder } from './ReverseGeocoder';

interface PaymentOption {
  type: 'efectivo' | 'trueque' | 'especie';
  amount?: number;
  description: string;
  icon: any;
}

export function CreateMission() {
  const [isCreating, setIsCreating] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    difficulty: 'Fácil',
    timeEstimate: '',
    maxParticipants: 5,
    location: '',
    locationCoords: { lat: 3.5836, lng: -76.4951 },
    isForKids: false,
    ageMin: 7,
    reward: 100
  });
  
  const [paymentOptions, setPaymentOptions] = useState<PaymentOption[]>([
    { type: 'efectivo', amount: 50000, description: '$50,000 COP', icon: DollarSign }
  ]);

  const categories = [
    { value: 'Medio Ambiente', icon: '🌱', color: 'bg-green-100 text-green-800' },
    { value: 'Tecnología', icon: '💻', color: 'bg-blue-100 text-blue-800' },
    { value: 'Educación', icon: '📚', color: 'bg-purple-100 text-purple-800' },
    { value: 'Agricultura', icon: '🌾', color: 'bg-orange-100 text-orange-800' },
    { value: 'Arte', icon: '🎨', color: 'bg-pink-100 text-pink-800' },
    { value: 'Deportes', icon: '⚽', color: 'bg-red-100 text-red-800' },
    { value: 'Cocina', icon: '👨‍🍳', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'Música', icon: '🎵', color: 'bg-indigo-100 text-indigo-800' }
  ];

  const difficulties = [
    { value: 'Súper Fácil', points: 50, color: 'bg-green-100 text-green-800', icon: '😊' },
    { value: 'Fácil', points: 100, color: 'bg-blue-100 text-blue-800', icon: '🙂' },
    { value: 'Medio', points: 200, color: 'bg-yellow-100 text-yellow-800', icon: '🤔' },
    { value: 'Difícil', points: 400, color: 'bg-red-100 text-red-800', icon: '😤' }
  ];

  const timeOptions = [
    '30 minutos', '1 hora', '2 horas', '3 horas', '4 horas',
    '1 día', '2 días', '1 semana', '2 semanas', '1 mes'
  ];

  const addPaymentOption = (type: PaymentOption['type']) => {
    const newOption: PaymentOption = {
      type,
      description: '',
      icon: type === 'efectivo' ? DollarSign : type === 'trueque' ? Handshake : Gift
    };
    
    switch (type) {
      case 'efectivo':
        newOption.amount = 20000;
        newOption.description = '$20,000 COP';
        break;
      case 'trueque':
        newOption.description = 'Intercambio de productos o servicios';
        break;
      case 'especie':
        newOption.description = 'Comida, materiales o productos';
        break;
    }
    
    setPaymentOptions([...paymentOptions, newOption]);
  };

  const removePaymentOption = (index: number) => {
    setPaymentOptions(paymentOptions.filter((_, i) => i !== index));
  };

  const updatePaymentOption = (index: number, field: string, value: any) => {
    const updated = paymentOptions.map((option, i) => 
      i === index ? { ...option, [field]: value } : option
    );
    setPaymentOptions(updated);
  };

  const calculateTotalReward = () => {
    const difficultyBonus = difficulties.find(d => d.value === formData.difficulty)?.points || 100;
    const categoryBonus = formData.isForKids ? 50 : 0;
    const participantBonus = formData.maxParticipants * 10;
    return difficultyBonus + categoryBonus + participantBonus;
  };

  const createMission = async () => {
    setLoading(true);
    try {
      const missionData = {
        ...formData,
        reward: calculateTotalReward(),
        paymentOptions,
        location: {
          lat: formData.locationCoords.lat,
          lng: formData.locationCoords.lng,
          address: formData.location || 'Yumbo, Valle del Cauca'
        },
        status: 'active',
        createdAt: new Date().toISOString()
      };

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-34f10c60/missions/create`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(missionData)
      });

      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          // Reset form
          setFormData({
            title: '',
            description: '',
            category: '',
            difficulty: 'Fácil',
            timeEstimate: '',
            maxParticipants: 5,
            location: '',
            locationCoords: { lat: 3.5836, lng: -76.4951 },
            isForKids: false,
            ageMin: 7,
            reward: 100
          });
          setPaymentOptions([
            { type: 'efectivo', amount: 50000, description: '$50,000 COP', icon: DollarSign }
          ]);
          setIsCreating(false);
          
          // Mostrar celebración
          alert('🎉 ¡Misión creada exitosamente! Ya está disponible para todos los héroes.');
        }
      }
    } catch (error) {
      console.error('Error creating mission:', error);
      alert('Error al crear la misión. ¡Inténtalo de nuevo!');
    }
    setLoading(false);
  };

  if (!isCreating) {
    return (
      <div className="w-full max-w-2xl mx-auto">
        <Card className="border-2 border-dashed border-blue-300 hover:border-blue-500 transition-all duration-300 hover:shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="space-y-4">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                <Plus className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">¡Crea tu Primera Misión!</h3>
              <p className="text-gray-600 max-w-md mx-auto">
                Comparte una tarea, proyecto o favor que necesites. Otros héroes de bondad te ayudarán y ganarán puntos.
              </p>
              <div className="flex flex-wrap justify-center gap-2 mb-4">
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  ✨ Súper fácil
                </Badge>
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  👶 Para todas las edades
                </Badge>
                <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                  🎁 Múltiples pagos
                </Badge>
              </div>
              <Button 
                onClick={() => setIsCreating(true)}
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                ¡Crear Misión Ahora!
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <Card className="border-2 border-blue-200 shadow-xl">
        <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
          <CardTitle className="flex items-center space-x-2">
            <Zap className="w-6 h-6 text-blue-600" />
            <span>Crear Nueva Misión</span>
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              {formData.isForKids ? '👶 Apta para niños' : '👥 Para todos'}
            </Badge>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="p-6 space-y-6">
          {/* Información básica */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="title" className="text-lg font-medium">
                  🎯 ¿Qué necesitas que hagan?
                </Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  placeholder="Ej: Ayudar a limpiar mi patio"
                  className="text-lg mt-2"
                />
              </div>
              
              <div>
                <Label htmlFor="description" className="text-lg font-medium">
                  📝 Cuéntanos más detalles
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Describe qué hay que hacer, qué materiales necesitas, etc."
                  rows={4}
                  className="mt-2"
                />
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label className="text-lg font-medium">🏷️ ¿Qué tipo de misión es?</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {categories.map((cat) => (
                    <Button
                      key={cat.value}
                      variant={formData.category === cat.value ? "default" : "outline"}
                      onClick={() => setFormData({...formData, category: cat.value})}
                      className="justify-start text-sm h-12"
                    >
                      <span className="mr-2">{cat.icon}</span>
                      {cat.value}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Configuración de dificultad y tiempo */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <Label className="text-lg font-medium">⚡ ¿Qué tan difícil es?</Label>
              <div className="space-y-2 mt-2">
                {difficulties.map((diff) => (
                  <Button
                    key={diff.value}
                    variant={formData.difficulty === diff.value ? "default" : "outline"}
                    onClick={() => setFormData({...formData, difficulty: diff.value})}
                    className="w-full justify-between text-sm"
                  >
                    <span>{diff.icon} {diff.value}</span>
                    <Badge variant="secondary">{diff.points} pts</Badge>
                  </Button>
                ))}
              </div>
            </div>
            
            <div>
              <Label className="text-lg font-medium">⏰ ¿Cuánto tiempo toma?</Label>
              <Select value={formData.timeEstimate} onValueChange={(value) => setFormData({...formData, timeEstimate: value})}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Selecciona tiempo" />
                </SelectTrigger>
                <SelectContent>
                  {timeOptions.map((time) => (
                    <SelectItem key={time} value={time}>{time}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-lg font-medium">👥 ¿Cuántas personas necesitas?</Label>
              <div className="mt-2 space-y-2">
                <Slider
                  value={[formData.maxParticipants]}
                  onValueChange={([value]) => setFormData({...formData, maxParticipants: value})}
                  min={1}
                  max={20}
                  step={1}
                  className="w-full"
                />
                <div className="text-center">
                  <Badge variant="outline" className="text-lg px-4 py-2">
                    {formData.maxParticipants} {formData.maxParticipants === 1 ? 'persona' : 'personas'}
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Configuración para niños */}
          <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-200">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-lg font-medium">👶 ¿Pueden participar niños?</Label>
                <p className="text-sm text-gray-600 mt-1">
                  Las misiones para niños son más fáciles y seguras
                </p>
              </div>
              <Switch
                checked={formData.isForKids}
                onCheckedChange={(checked) => setFormData({...formData, isForKids: checked})}
              />
            </div>
            
            {formData.isForKids && (
              <div className="mt-4">
                <Label className="text-base font-medium">Edad mínima recomendada</Label>
                <div className="mt-2 space-y-2">
                  <Slider
                    value={[formData.ageMin]}
                    onValueChange={([value]) => setFormData({...formData, ageMin: value})}
                    min={5}
                    max={17}
                    step={1}
                    className="w-full"
                  />
                  <div className="text-center">
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                      Desde {formData.ageMin} años
                    </Badge>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Opciones de pago */}
          <div className="space-y-4">
            <Label className="text-lg font-medium">💰 ¿Cómo vas a pagar?</Label>
            <div className="space-y-3">
              {paymentOptions.map((option, index) => (
                <Card key={index} className="border border-gray-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <option.icon className="w-5 h-5 text-blue-600" />
                        <div>
                          <Badge variant="outline" className="mb-1">
                            {option.type === 'efectivo' ? '💵 Efectivo' : 
                             option.type === 'trueque' ? '🤝 Trueque' : '🎁 En especie'}
                          </Badge>
                          {option.type === 'efectivo' ? (
                            <Input
                              type="number"
                              value={option.amount || ''}
                              onChange={(e) => {
                                const amount = parseInt(e.target.value);
                                updatePaymentOption(index, 'amount', amount);
                                updatePaymentOption(index, 'description', `$${amount.toLocaleString()} COP`);
                              }}
                              placeholder="Cantidad en COP"
                              className="w-32"
                            />
                          ) : (
                            <Input
                              value={option.description}
                              onChange={(e) => updatePaymentOption(index, 'description', e.target.value)}
                              placeholder={option.type === 'trueque' ? 'Ej: Te enseño inglés a cambio' : 'Ej: Pizza y gaseosas'}
                              className="max-w-md"
                            />
                          )}
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => removePaymentOption(index)}
                        className="text-red-600 hover:text-red-700"
                      >
                        Eliminar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  onClick={() => addPaymentOption('efectivo')}
                  className="flex items-center space-x-2"
                >
                  <DollarSign className="w-4 h-4" />
                  <span>Agregar Efectivo</span>
                </Button>
                <Button
                  variant="outline"
                  onClick={() => addPaymentOption('trueque')}
                  className="flex items-center space-x-2"
                >
                  <Handshake className="w-4 h-4" />
                  <span>Agregar Trueque</span>
                </Button>
                <Button
                  variant="outline"
                  onClick={() => addPaymentOption('especie')}
                  className="flex items-center space-x-2"
                >
                  <Gift className="w-4 h-4" />
                  <span>Agregar En Especie</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Ubicación con Geolocalización Inteligente */}
          <div className="space-y-3">
            <div>
              <Label className="text-lg font-medium flex items-center space-x-2">
                <MapPin className="w-5 h-5 text-blue-600" />
                <span>📍 ¿Dónde es la misión?</span>
              </Label>
              <p className="text-sm text-gray-600 mt-1">
                Usa tu GPS para obtener la dirección exacta o escribe una dirección manualmente
              </p>
            </div>

            {/* Geocodificador inverso GPS */}
            <ReverseGeocoder
              onAddressFound={(location) => {
                setFormData({
                  ...formData,
                  location: location.address,
                  locationCoords: { lat: location.lat, lng: location.lng }
                });
              }}
            />

            {/* Búsqueda manual de ubicación */}
            <div className="mt-4">
              <Label className="text-sm font-medium text-gray-700 mb-2 block">
                O escribe la dirección manualmente:
              </Label>
              <LocationSearch
                onLocationSelect={(location) => {
                  setFormData({
                    ...formData, 
                    location: location.address,
                    locationCoords: { lat: location.lat, lng: location.lng }
                  });
                }}
                initialValue={formData.location}
                placeholder="Ej: Calle 15 #12-34, Barrio San Carlos, Yumbo"
                focusOnYumbo={true}
              />
            </div>
            
            {formData.location && (
              <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-start space-x-2">
                  <MapPin className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-green-800">✅ Ubicación guardada con precisión GPS</p>
                    <p className="text-xs text-green-700 mt-1">{formData.location}</p>
                    <div className="flex items-center space-x-4 mt-2 text-xs text-green-600">
                      <span>📍 Lat: {formData.locationCoords.lat.toFixed(6)}</span>
                      <span>📍 Lng: {formData.locationCoords.lng.toFixed(6)}</span>
                    </div>
                    <p className="text-xs text-green-600 mt-2">
                      🔍 Las personas podrán encontrar misiones similares cerca de esta ubicación exacta
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Resumen de recompensas */}
          <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-2 border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-lg">🏆 Recompensa Total</h4>
                  <p className="text-sm text-gray-600">Puntos de bondad que ganarán los participantes</p>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-green-600 flex items-center">
                    <Star className="w-8 h-8 mr-2" />
                    {calculateTotalReward()}
                  </div>
                  <p className="text-sm text-gray-600">puntos cada uno</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Botones de acción */}
          <div className="flex space-x-4">
            <Button
              variant="outline"
              onClick={() => setIsCreating(false)}
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button
              onClick={createMission}
              disabled={loading || !formData.title || !formData.description || !formData.category}
              className="flex-1 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white"
            >
              {loading ? (
                <>
                  <Heart className="w-5 h-5 mr-2 animate-pulse" />
                  Creando...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  ¡Publicar Misión!
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}