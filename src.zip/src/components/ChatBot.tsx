import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { Send, Bot, User, Lightbulb, MapPin, Calendar } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  suggestions?: string[];
}

const botResponses = {
  greeting: [
    "¡Hola! Soy EcoBot, tu asistente personal para hacer el bien. ¿En qué puedo ayudarte hoy?",
    "¡Bienvenido! Estoy aquí para ayudarte a encontrar misiones, calcular tu impacto o responder cualquier pregunta."
  ],
  missions: [
    "He encontrado 3 misiones cerca de ti que podrían interesarte:",
    "Basándome en tu perfil y ubicación, estas son las mejores misiones para ti:"
  ],
  impact: [
    "Tu impacto hasta ahora es increíble. Has ahorrado 2.8 toneladas de CO2 y ayudado a 1,243 personas.",
    "¡Felicidades! Tu nivel de bondad actual es 847. Estás en el top 5% de usuarios más activos."
  ],
  tips: [
    "💡 Consejo: Completa misiones consecutivas para mantener tu racha y ganar puntos extra.",
    "🌱 Tip ecológico: Usar transporte público para llegar a las misiones suma puntos de sostenibilidad."
  ]
};

const quickSuggestions = [
  "Encuentra misiones cerca de mí",
  "¿Cuál es mi impacto actual?",
  "Dame consejos para mejorar mi nivel",
  "¿Qué misiones me recomiendas?",
  "Muéstrame estadísticas del clima"
];

export function ChatBot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "¡Hola! Soy EcoBot 🤖🌱 Tu asistente personal para crear un impacto positivo. ¿Cómo puedo ayudarte hoy?",
      sender: 'bot',
      timestamp: new Date(),
      suggestions: quickSuggestions.slice(0, 3)
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateBotResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('misión') || message.includes('trabajo') || message.includes('cerca')) {
      return `${botResponses.missions[Math.floor(Math.random() * botResponses.missions.length)]}

📍 **Limpieza de Playa** - 250 puntos - 2.1km
🌱 **Huerto Urbano** - 180 puntos - 3.2km  
💻 **Clases de Programación** - 320 puntos - 2.7km

¿Te interesa alguna de estas misiones?`;
    }
    
    if (message.includes('impacto') || message.includes('estadística') || message.includes('nivel')) {
      return `${botResponses.impact[Math.floor(Math.random() * botResponses.impact.length)]}

📊 **Tu Resumen:**
⭐ Nivel de Bondad: 847
🎯 Misiones Completadas: 156
👥 Personas Ayudadas: 1,243
🌍 CO2 Ahorrado: 2.8 toneladas
🔥 Racha Actual: 23 días

¡Sigue así! Estás haciendo una diferencia real.`;
    }
    
    if (message.includes('consejo') || message.includes('tip') || message.includes('mejorar')) {
      return `${botResponses.tips[Math.floor(Math.random() * botResponses.tips.length)]}

🚀 **Más consejos para ti:**
• Completa misiones en grupo para ganar puntos de colaboración
• Documenta tu progreso con fotos para inspirar a otros
• Participa en misiones de diferentes categorías para ser más versátil
• Invita amigos para ganar bonificaciones de referido

¿Quieres que te ayude con algo más específico?`;
    }
    
    if (message.includes('clima') || message.includes('calentamiento') || message.includes('temperatura')) {
      return `🌡️ **Estado del Clima Global:**

⏰ Tiempo restante para 1.5°C: 5 años, 84 días
📈 Temperatura actual vs pre-industrial: +1.1°C
🔥 Meta: Mantener bajo +1.5°C para 2030

**Tu contribución:**
Has evitado 2.8 toneladas de CO2 este año. ¡Eso equivale a plantar 127 árboles! 🌳

¿Te interesa unirte a más misiones climáticas?`;
    }
    
    return `Entiendo tu consulta. Estoy aquí para ayudarte con:

🎯 Encontrar misiones perfectas para ti
📊 Revisar tu impacto y estadísticas  
💡 Darte consejos personalizados
🌍 Información sobre el cambio climático
👥 Conectarte con otros usuarios

¿Sobre qué te gustaría saber más?`;
  };

  const handleSendMessage = async (messageContent?: string) => {
    const content = messageContent || input.trim();
    if (!content) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-34f10c60/chat`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: content,
          userId: 'user-1' // En un app real, esto vendría de la sesión del usuario
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          const botResponse: Message = {
            id: (Date.now() + 1).toString(),
            content: data.response,
            sender: 'bot',
            timestamp: new Date(),
            suggestions: data.suggestions || undefined
          };
          setMessages(prev => [...prev, botResponse]);
        } else {
          throw new Error(data.error);
        }
      } else {
        throw new Error('Network response was not ok');
      }
    } catch (error) {
      console.error('Chat error:', error);
      // Fallback a respuesta local
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: generateBotResponse(content),
        sender: 'bot',
        timestamp: new Date(),
        suggestions: Math.random() > 0.5 ? quickSuggestions.slice(0, 3) : undefined
      };
      setMessages(prev => [...prev, botResponse]);
    }
    
    setIsTyping(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto h-[600px] flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center space-x-3">
          <Avatar className="w-10 h-10 bg-gradient-to-br from-green-400 to-blue-500">
            <AvatarFallback className="text-white">
              <Bot className="w-5 h-5" />
            </AvatarFallback>
          </Avatar>
          <div>
            <h3 className="flex items-center space-x-2">
              <span>EcoBot</span>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                En línea
              </Badge>
            </h3>
            <p className="text-sm text-gray-600">Tu asistente para el cambio positivo</p>
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        {/* Área de mensajes */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${
                message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}
            >
              <Avatar className="w-8 h-8">
                {message.sender === 'bot' ? (
                  <AvatarFallback className="bg-gradient-to-br from-green-400 to-blue-500 text-white">
                    <Bot className="w-4 h-4" />
                  </AvatarFallback>
                ) : (
                  <AvatarFallback className="bg-blue-500 text-white">
                    <User className="w-4 h-4" />
                  </AvatarFallback>
                )}
              </Avatar>
              
              <div className={`flex-1 ${message.sender === 'user' ? 'text-right' : ''}`}>
                <div
                  className={`inline-block p-3 rounded-lg max-w-[80%] ${
                    message.sender === 'user'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 text-gray-900'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
                
                {message.suggestions && (
                  <div className="mt-3 space-y-2">
                    <p className="text-sm text-gray-500">Sugerencias:</p>
                    <div className="flex flex-wrap gap-2">
                      {message.suggestions.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          onClick={() => handleSendMessage(suggestion)}
                          className="text-xs"
                        >
                          <Lightbulb className="w-3 h-3 mr-1" />
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex items-start space-x-3">
              <Avatar className="w-8 h-8">
                <AvatarFallback className="bg-gradient-to-br from-green-400 to-blue-500 text-white">
                  <Bot className="w-4 h-4" />
                </AvatarFallback>
              </Avatar>
              <div className="bg-gray-100 p-3 rounded-lg">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Área de input */}
        <div className="border-t p-4">
          <div className="flex space-x-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Escribe tu mensaje..."
              className="flex-1"
              disabled={isTyping}
            />
            <Button 
              onClick={() => handleSendMessage()}
              disabled={!input.trim() || isTyping}
              className="shrink-0"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}