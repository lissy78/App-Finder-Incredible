import { Alert, AlertDescription } from './ui/alert';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { 
  MapPin, 
  CheckCircle, 
  AlertCircle, 
  Navigation, 
  Clock,
  Zap,
  Crosshair,
  Lock
} from 'lucide-react';
import { LocationState } from '../utils/useRealTimeLocation';
import { motion } from 'motion/react';

interface RealTimeLocationStatusProps {
  locationState: LocationState & {
    requestLocation: () => void;
    startTracking: () => void;
    stopTracking: () => void;
  };
}

export function RealTimeLocationStatus({ locationState }: RealTimeLocationStatusProps) {
  const { 
    location, 
    error, 
    isTracking, 
    permissionState, 
    lastUpdate,
    requestLocation,
    startTracking
  } = locationState;

  // Renderizar según el estado de permisos
  if (permissionState === 'denied') {
    return (
      <Alert className="mb-6 bg-yellow-50 border-2 border-yellow-300">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3 flex-1">
            <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div className="space-y-2 flex-1">
              <AlertDescription className="text-yellow-900">
                <p className="font-medium">📍 Permisos de ubicación denegados</p>
                <p className="text-sm mt-1">
                  Para usar tu ubicación en tiempo real, debes permitir el acceso:
                </p>
                <ol className="list-decimal list-inside text-sm mt-2 space-y-1 ml-2">
                  <li>Haz clic en el ícono <Lock className="w-3 h-3 inline" /> (candado) en la barra de direcciones</li>
                  <li>Busca "Ubicación" y selecciona "Permitir"</li>
                  <li>Recarga la página</li>
                </ol>
                <p className="text-sm mt-2 bg-yellow-100 p-2 rounded border border-yellow-200">
                  💡 Mientras tanto, estamos usando <strong>Yumbo, Valle del Cauca</strong> como ubicación predeterminada.
                </p>
              </AlertDescription>
            </div>
          </div>
        </div>
      </Alert>
    );
  }

  if (permissionState === 'prompt' || permissionState === 'unknown') {
    return (
      <Alert className="mb-6 bg-blue-50 border-2 border-blue-300">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3 flex-1">
            <Navigation className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="space-y-3 flex-1">
              <AlertDescription className="text-blue-900">
                <p className="font-medium">🌍 Activa tu ubicación en tiempo real</p>
                <p className="text-sm mt-1">
                  GoodImpact necesita acceso a tu ubicación GPS para mostrarte las misiones más cercanas a ti.
                </p>
              </AlertDescription>
              <Button 
                onClick={requestLocation}
                className="bg-blue-600 hover:bg-blue-700"
                size="sm"
              >
                <Crosshair className="w-4 h-4 mr-2" />
                Permitir Ubicación GPS
              </Button>
            </div>
          </div>
        </div>
      </Alert>
    );
  }

  if (permissionState === 'granted' && isTracking && location) {
    const accuracy = location.accuracy ? Math.round(location.accuracy) : null;
    const timeSinceUpdate = lastUpdate 
      ? Math.round((Date.now() - lastUpdate.getTime()) / 1000) 
      : null;

    return (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <Card className="mb-6 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-300">
          <div className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center space-x-2">
                <motion.div
                  animate={{ 
                    scale: [1, 1.2, 1],
                    opacity: [1, 0.8, 1]
                  }}
                  transition={{ 
                    duration: 2, 
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </motion.div>
                <div>
                  <p className="font-medium text-green-900 flex items-center">
                    ✅ Ubicación en tiempo real activa
                    <Badge className="ml-2 bg-green-600 text-white animate-pulse" variant="default">
                      <Zap className="w-3 h-3 mr-1" />
                      EN VIVO
                    </Badge>
                  </p>
                  <p className="text-sm text-green-700">
                    Tu posición se actualiza automáticamente mientras navegas
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="bg-white rounded-lg p-3 border border-green-200">
                <div className="flex items-center space-x-2 mb-1">
                  <MapPin className="w-4 h-4 text-green-600" />
                  <span className="text-xs text-gray-600">Coordenadas GPS</span>
                </div>
                <p className="text-sm font-mono">
                  {location.lat.toFixed(6)}, {location.lng.toFixed(6)}
                </p>
              </div>

              {accuracy && (
                <div className="bg-white rounded-lg p-3 border border-green-200">
                  <div className="flex items-center space-x-2 mb-1">
                    <Crosshair className="w-4 h-4 text-green-600" />
                    <span className="text-xs text-gray-600">Precisión GPS</span>
                  </div>
                  <p className="text-sm font-medium">
                    ±{accuracy}m
                    {accuracy < 50 && <span className="text-green-600 ml-2">🎯 Excelente</span>}
                    {accuracy >= 50 && accuracy < 100 && <span className="text-yellow-600 ml-2">✓ Buena</span>}
                    {accuracy >= 100 && <span className="text-orange-600 ml-2">⚠ Regular</span>}
                  </p>
                </div>
              )}

              {lastUpdate && (
                <div className="bg-white rounded-lg p-3 border border-green-200">
                  <div className="flex items-center space-x-2 mb-1">
                    <Clock className="w-4 h-4 text-green-600" />
                    <span className="text-xs text-gray-600">Última actualización</span>
                  </div>
                  <p className="text-sm">
                    {timeSinceUpdate !== null && timeSinceUpdate < 60 
                      ? `Hace ${timeSinceUpdate}s`
                      : lastUpdate.toLocaleTimeString()
                    }
                    {timeSinceUpdate !== null && timeSinceUpdate < 5 && (
                      <motion.span 
                        className="ml-2 text-green-600"
                        animate={{ opacity: [1, 0.5, 1] }}
                        transition={{ duration: 1, repeat: Infinity }}
                      >
                        ●
                      </motion.span>
                    )}
                  </p>
                </div>
              )}
            </div>

            {location.speed !== null && location.speed !== undefined && location.speed > 0 && (
              <div className="mt-3 bg-blue-50 p-2 rounded border border-blue-200">
                <p className="text-xs text-blue-800">
                  🚗 Velocidad: {(location.speed * 3.6).toFixed(1)} km/h
                </p>
              </div>
            )}
          </div>
        </Card>
      </motion.div>
    );
  }

  // No mostrar error si estamos usando el fallback de Yumbo exitosamente
  if (error && location && location.lat === 3.5836 && location.lng === -76.4951) {
    return (
      <Alert className="mb-6 bg-yellow-50 border-2 border-yellow-300">
        <div className="flex items-start space-x-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <AlertDescription className="text-yellow-900">
              <p className="font-medium">📍 Usando ubicación predeterminada</p>
              <p className="text-sm mt-1">
                No se pudo obtener tu ubicación GPS. Estamos usando <strong>Yumbo, Valle del Cauca</strong> como ubicación predeterminada.
                Todas las misiones en la región están disponibles.
              </p>
              {permissionState === 'denied' && (
                <p className="text-sm mt-2 bg-yellow-100 p-2 rounded border border-yellow-200">
                  💡 Para usar tu ubicación real, haz clic en el ícono de candado en la barra de direcciones y permite el acceso a la ubicación.
                </p>
              )}
            </AlertDescription>
          </div>
        </div>
      </Alert>
    );
  }

  if (error) {
    return (
      <Alert className="mb-6 bg-red-50 border-2 border-red-300">
        <div className="flex items-start space-x-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <AlertDescription className="text-red-900">
              <p className="font-medium">Error de geolocalización</p>
              <p className="text-sm mt-1">{error}</p>
              <Button 
                onClick={startTracking}
                variant="outline"
                size="sm"
                className="mt-3 border-red-300 text-red-700 hover:bg-red-100"
              >
                <Navigation className="w-4 h-4 mr-2" />
                Intentar de nuevo
              </Button>
            </AlertDescription>
          </div>
        </div>
      </Alert>
    );
  }

  return null;
}
