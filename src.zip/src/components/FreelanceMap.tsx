import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { MapPin, Clock, DollarSign, Users, Navigation, RefreshCw, Zap, Plus, CheckCircle } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { CreateMission } from './CreateMission';
import { MissionCompletion } from './MissionCompletion';
import { GeoEnhancedMap } from './GeoEnhancedMap';
import { GeoStatsBar } from './GeoStatsBar';
import { GeoInfoPanel } from './GeoInfoPanel';
import { GeoDemo } from './GeoDemo';
import { GeolocationStatus } from './GeolocationStatus';
import { NearbyMissionsFinder } from './NearbyMissionsFinder';
import { RealTimeLocationStatus } from './RealTimeLocationStatus';
import { LocationControlPanel } from './LocationControlPanel';
import { useRealTimeLocation } from '../utils/useRealTimeLocation';

const YUMBO_CENTER = { lat: 3.5836, lng: -76.4951 };

interface Mission {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  reward: number;
  participants: number;
  maxParticipants: number;
  timeEstimate: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  isUrgent?: boolean;
}

export function FreelanceMap() {
  const [selectedMission, setSelectedMission] = useState<Mission | null>(null);
  const [missions, setMissions] = useState<Mission[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('Todas');
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [activeTab, setActiveTab] = useState('explore');
  const [completingMission, setCompletingMission] = useState<Mission | null>(null);
  
  // Hook de geolocalización en tiempo real
  const realTimeLocation = useRealTimeLocation(true);

  // Mock missions specific to Yumbo, Valle del Cauca con coordenadas GPS precisas
  const mockMissions: Mission[] = [
    {
      id: '1',
      title: 'Limpieza del Parque Central Yumbo',
      description: 'Ayudar a limpiar y mantener el parque central de Yumbo. Incluye recoger basura, podar plantas menores y organizar los juegos infantiles.',
      category: 'Medio Ambiente',
      difficulty: 'Fácil',
      reward: 150,
      participants: 3,
      maxParticipants: 8,
      timeEstimate: '3 horas',
      location: { lat: 3.583600, lng: -76.495100, address: 'Parque Central, Calle 13 #14-15, Yumbo, Valle del Cauca' },
      isUrgent: true
    },
    {
      id: '2',
      title: 'Desarrollo web para Panadería Local',
      description: 'Crear una página web sencilla para una panadería familiar en Yumbo. Incluye catálogo de productos y información de contacto.',
      category: 'Tecnología',
      difficulty: 'Medio',
      reward: 300,
      participants: 1,
      maxParticipants: 2,
      timeEstimate: '1 semana',
      location: { lat: 3.582023, lng: -76.496032, address: 'Carrera 14 #12-45, Centro Comercial Yumbo Plaza, Yumbo, Valle del Cauca' }
    },
    {
      id: '3',
      title: 'Clases de refuerzo escolar',
      description: 'Apoyo académico en matemáticas y español para niños de primaria en el barrio Villa del Sol.',
      category: 'Educación',
      difficulty: 'Fácil',
      reward: 200,
      participants: 2,
      maxParticipants: 4,
      timeEstimate: '2 horas diarias',
      location: { lat: 3.585021, lng: -76.493067, address: 'Calle 18 #16-20, Barrio Villa del Sol, Yumbo, Valle del Cauca' }
    },
    {
      id: '4',
      title: 'Huerta Comunitaria Orgánica',
      description: 'Ayudar a establecer una huerta orgánica comunitaria en el barrio La Esperanza. Siembra, riego y mantenimiento.',
      category: 'Agricultura',
      difficulty: 'Medio',
      reward: 250,
      participants: 5,
      maxParticipants: 10,
      timeEstimate: '4 horas',
      location: { lat: 3.580014, lng: -76.492035, address: 'Calle 8 #10-30, Barrio La Esperanza, Yumbo, Valle del Cauca' },
      isUrgent: true
    },
    {
      id: '5',
      title: 'Campaña de Reciclaje Industrial',
      description: 'Organizar jornada de reciclaje en la zona industrial de Yumbo. Separación de materiales y educación ambiental.',
      category: 'Medio Ambiente',
      difficulty: 'Medio',
      reward: 180,
      participants: 4,
      maxParticipants: 12,
      timeEstimate: '5 horas',
      location: { lat: 3.590012, lng: -76.500025, address: 'Zona Industrial Acopi, Km 1 Vía Cali-Yumbo, Yumbo, Valle del Cauca' }
    },
    {
      id: '6',
      title: 'App móvil para transporte sostenible',
      description: 'Desarrollar una aplicación móvil para optimizar rutas de transporte público en Yumbo y reducir emisiones de CO2.',
      category: 'Tecnología',
      difficulty: 'Difícil',
      reward: 500,
      participants: 0,
      maxParticipants: 3,
      timeEstimate: '3 semanas',
      location: { lat: 3.582156, lng: -76.493345, address: 'Terminal de Transporte, Carrera 13 #8-25, Yumbo, Valle del Cauca' }
    },
    {
      id: '7',
      title: 'Taller de arte urbano con reciclaje',
      description: 'Crear murales ecológicos usando materiales reciclados en la institución educativa. Arte con conciencia ambiental.',
      category: 'Arte',
      difficulty: 'Fácil',
      reward: 220,
      participants: 2,
      maxParticipants: 6,
      timeEstimate: '4 horas',
      location: { lat: 3.584567, lng: -76.494123, address: 'Institución Educativa José María Córdoba, Yumbo, Valle del Cauca' }
    },
    {
      id: '8',
      title: 'Cocina comunitaria nutritiva',
      description: 'Enseñar preparación de alimentos nutritivos y económicos para familias de bajos recursos en Yumbo.',
      category: 'Cocina',
      difficulty: 'Fácil',
      reward: 180,
      participants: 1,
      maxParticipants: 5,
      timeEstimate: '3 horas',
      location: { lat: 3.583891, lng: -76.495678, address: 'Casa Comunal, Barrio El Porvenir, Yumbo, Valle del Cauca' },
      isUrgent: true
    }
  ];

  useEffect(() => {
    loadMissions();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadMissions, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadMissions = async () => {
    setLoading(true);
    setLastUpdate(new Date());
    
    try {
      // Intentar cargar desde el servidor
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-34f10c60/missions`;
      const params = new URLSearchParams();
      
      if (selectedCategory !== 'Todas') {
        params.append('category', selectedCategory);
      }
      
      // Agregar coordenadas de Yumbo para filtrado geográfico
      params.append('lat', '3.5836');
      params.append('lng', '-76.4951');
      params.append('radius', '25');
      
      const fullUrl = `${url}?${params.toString()}`;
      
      const response = await fetch(fullUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && data.missions && data.missions.length > 0) {
          setMissions(data.missions);
          console.log('Missions loaded from server:', data.missions.length);
        } else {
          console.log('No missions from server, using mock data');
          setMissions(mockMissions);
        }
      } else {
        console.error('Server response error:', response.status, response.statusText);
        setMissions(mockMissions);
      }
    } catch (error) {
      console.error('Error loading missions:', error);
      console.log('Using mock data as fallback');
      setMissions(mockMissions);
    }
    setLoading(false);
  };

  const joinMission = async (missionId: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-34f10c60/missions/${missionId}/join`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          loadMissions(); // Recargar misiones
          alert('¡Te has unido a la misión exitosamente! 🎉');
        }
      }
    } catch (error) {
      console.error('Error joining mission:', error);
      alert('Error al unirse a la misión. ¡Inténtalo de nuevo!');
    }
  };

  const filteredMissions = selectedCategory === 'Todas' 
    ? missions 
    : missions.filter(mission => mission.category === selectedCategory);

  const categories = ['Todas', 'Medio Ambiente', 'Tecnología', 'Educación', 'Agricultura'];

  if (completingMission) {
    return (
      <MissionCompletion
        mission={completingMission}
        onComplete={() => {
          setCompletingMission(null);
          loadMissions(); // Recargar misiones
        }}
        onCancel={() => setCompletingMission(null)}
      />
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto">
      {/* Header principal */}
      <div className="mb-6 text-center">
        <div className="flex items-center justify-center space-x-2 mb-2">
          <Navigation className="w-6 h-6 text-blue-600" />
          <h2 className="text-3xl font-bold">GoodImpact Yumbo</h2>
          <div className="flex items-center space-x-1 text-green-600">
            <Zap className="w-4 h-4 animate-pulse" />
            <span className="text-sm">En vivo</span>
          </div>
        </div>
        <p className="text-gray-600">Conectando héroes de bondad en Valle del Cauca</p>
      </div>

      {/* Estado de geolocalización en tiempo real */}
      <RealTimeLocationStatus locationState={realTimeLocation} />

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="explore" className="flex items-center space-x-2">
            <MapPin className="w-4 h-4" />
            <span>Explorar</span>
          </TabsTrigger>
          <TabsTrigger value="nearby" className="flex items-center space-x-2">
            <Navigation className="w-4 h-4" />
            <span>Cerca de Mí</span>
          </TabsTrigger>
          <TabsTrigger value="create" className="flex items-center space-x-2">
            <Plus className="w-4 h-4" />
            <span>Crear</span>
          </TabsTrigger>
          <TabsTrigger value="my-missions" className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4" />
            <span>Mis Misiones</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="explore">
          <div className="space-y-6">
            {/* Barra de estadísticas de geolocalización */}
            <GeoStatsBar 
              missions={filteredMissions}
              userLocation={realTimeLocation.location}
            />
            {/* Header con controles */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center space-x-2">
                <h3 className="text-xl font-bold">Misiones Disponibles</h3>
              </div>
              
              <div className="flex items-center space-x-3">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={loadMissions}
                  disabled={loading}
                  className="flex items-center space-x-1"
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                  <span>Actualizar</span>
                </Button>
              </div>
            </div>
            
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <span>📍 {filteredMissions.length} misiones disponibles</span>
              <span>🕒 Última actualización: {lastUpdate.toLocaleTimeString()}</span>
              <span>📍 Radio: 25 km desde tu ubicación</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Mapa Mejorado con Geolocalización */}
              <GeoEnhancedMap
                missions={filteredMissions}
                selectedMission={selectedMission}
                onMissionSelect={setSelectedMission}
                userLocation={realTimeLocation.location}
              />

              {/* Lista de Misiones */}
              <div className="space-y-4">
                {loading && (
                  <div className="flex flex-col items-center justify-center py-12 space-y-4">
                    <RefreshCw className="w-8 h-8 animate-spin text-blue-600" />
                    <p className="text-gray-600">Buscando misiones en tiempo real...</p>
                    <p className="text-sm text-gray-500">Conectando con Yumbo, Valle del Cauca</p>
                  </div>
                )}
                
                {!loading && filteredMissions.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-12 space-y-4">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                      <MapPin className="w-8 h-8 text-gray-400" />
                    </div>
                    <div className="text-center space-y-2">
                      <h4 className="font-medium text-gray-900">No hay misiones disponibles</h4>
                      <p className="text-sm text-gray-600">
                        {selectedCategory === 'Todas' 
                          ? 'No encontramos misiones cerca de tu ubicación en este momento.'
                          : `No hay misiones de "${selectedCategory}" disponibles actualmente.`
                        }
                      </p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={loadMissions}
                        className="mt-3"
                      >
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Intentar de nuevo
                      </Button>
                    </div>
                  </div>
                )}

                {filteredMissions.map((mission) => (
                  <Card 
                    key={mission.id} 
                    className={`cursor-pointer transition-all hover:shadow-lg border-l-4 ${
                      selectedMission?.id === mission.id 
                        ? 'ring-2 ring-blue-500 border-l-blue-500 bg-blue-50/50' 
                        : mission.category === 'Medio Ambiente' 
                          ? 'border-l-green-500 hover:border-l-green-600'
                          : mission.category === 'Tecnología'
                            ? 'border-l-blue-500 hover:border-l-blue-600'
                            : mission.category === 'Educación'
                              ? 'border-l-purple-500 hover:border-l-purple-600'
                              : 'border-l-orange-500 hover:border-l-orange-600'
                    }`}
                    onClick={() => setSelectedMission(mission)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h4 className="font-semibold text-lg mb-1 flex items-center">
                            {mission.title}
                            {mission.isUrgent && (
                              <Badge variant="destructive" className="ml-2 text-xs animate-pulse">
                                ¡URGENTE!
                              </Badge>
                            )}
                          </h4>
                          <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                            {mission.description}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-2 mb-3">
                        <Badge variant="secondary" className="text-xs">
                          {mission.category}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {mission.difficulty}
                        </Badge>
                        <Badge variant="outline" className="text-xs text-green-600">
                          +{mission.reward} pts
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm text-gray-600 mb-4">
                        <div className="flex items-center space-x-1">
                          <MapPin className="w-3 h-3" />
                          <span className="truncate">{mission.location.address}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>{mission.timeEstimate}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Users className="w-3 h-3" />
                          <span>{mission.participants}/{mission.maxParticipants} participantes</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <DollarSign className="w-3 h-3 text-green-600" />
                          <span className="font-medium text-green-600">{mission.reward} puntos</span>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          className="flex-1"
                          onClick={(e) => {
                            e.stopPropagation();
                            joinMission(mission.id);
                          }}
                          disabled={mission.participants >= mission.maxParticipants}
                        >
                          {mission.participants >= mission.maxParticipants ? 'Completa' : 'Unirse'}
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            setCompletingMission(mission);
                          }}
                        >
                          Completar
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
            
            {/* Panel informativo sobre geolocalización */}
            <GeoInfoPanel />
          </div>
        </TabsContent>

        <TabsContent value="nearby">
          <div className="space-y-6">
            <NearbyMissionsFinder 
              currentLocation={realTimeLocation.location || undefined}
              maxDistance={5}
            />
          </div>
        </TabsContent>

        <TabsContent value="create">
          <div className="space-y-6">
            {/* Panel de control de ubicación */}
            <LocationControlPanel
              isTracking={realTimeLocation.isTracking}
              permissionState={realTimeLocation.permissionState}
              onToggleTracking={(enabled) => {
                if (enabled) {
                  realTimeLocation.startTracking();
                } else {
                  realTimeLocation.stopTracking();
                }
              }}
              onRequestPermission={realTimeLocation.requestLocation}
              accuracy={realTimeLocation.location?.accuracy}
              lastUpdate={realTimeLocation.lastUpdate}
            />
            
            <CreateMission />
            
            {/* Demo de geolocalización */}
            <GeoDemo />
          </div>
        </TabsContent>

        <TabsContent value="my-missions">
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Mis Misiones</h3>
            <p className="text-gray-600 mb-6">Aquí verás el historial de tus misiones completadas y en progreso</p>
            <Button onClick={() => setActiveTab('create')} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Crear Mi Primera Misión
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}