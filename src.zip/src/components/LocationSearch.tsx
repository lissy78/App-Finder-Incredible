import { useState, useEffect, useRef } from 'react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { MapPin, Navigation, Search, Loader2, CheckCircle } from 'lucide-react';

interface LocationResult {
  place_name: string;
  center: [number, number]; // [lng, lat]
  relevance: number;
  context?: Array<{
    id: string;
    text: string;
  }>;
}

interface LocationSearchProps {
  onLocationSelect: (location: {
    lat: number;
    lng: number;
    address: string;
  }) => void;
  initialValue?: string;
  placeholder?: string;
  focusOnYumbo?: boolean;
}

export function LocationSearch({ 
  onLocationSelect, 
  initialValue = '', 
  placeholder = "Escribe una dirección en Yumbo...",
  focusOnYumbo = true 
}: LocationSearchProps) {
  const [query, setQuery] = useState(initialValue);
  const [suggestions, setSuggestions] = useState<LocationResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<LocationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const debounceRef = useRef<NodeJS.Timeout>();
  const inputRef = useRef<HTMLInputElement>(null);

  // Coordenadas del centro de Yumbo para priorizar resultados locales
  const YUMBO_CENTER = { lat: 3.5836, lng: -76.4951 };
  const SEARCH_RADIUS = 25; // km

  useEffect(() => {
    if (query.length < 3) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    debounceRef.current = setTimeout(() => {
      searchLocations(query);
    }, 300);

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, [query]);

  const searchLocations = async (searchQuery: string) => {
    setLoading(true);
    setError(null);
    
    try {
      // Usar una API de geocoding gratuita más confiable
      const geocodingQuery = focusOnYumbo 
        ? `${searchQuery}, Yumbo, Valle del Cauca, Colombia`
        : `${searchQuery}, Colombia`;
      
      // Usar OpenStreetMap Nominatim (gratis y confiable)
      const url = `https://nominatim.openstreetmap.org/search?` +
        `q=${encodeURIComponent(geocodingQuery)}&` +
        `format=geojson&` +
        `addressdetails=1&` +
        `limit=8&` +
        `countrycodes=co&` +
        `accept-language=es`;

      const response = await fetch(url, {
        headers: {
          'User-Agent': 'GoodImpact-App/1.0'
        }
      });
      
      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.features && data.features.length > 0) {
        // Filtrar y priorizar resultados de Yumbo y Valle del Cauca
        const filteredResults = data.features
          .filter((feature: any) => {
            if (!focusOnYumbo) return true;
            
            const placeName = feature.properties?.display_name?.toLowerCase() || '';
            const isInYumbo = placeName.includes('yumbo');
            const isInValle = placeName.includes('valle del cauca') || placeName.includes('colombia');
            
            return isInValle;
          })
          .map((feature: any) => ({
            place_name: feature.properties?.display_name || 'Ubicación sin nombre',
            center: feature.geometry?.coordinates || [YUMBO_CENTER.lng, YUMBO_CENTER.lat],
            relevance: 0.8,
            context: []
          }))
          .sort((a: LocationResult, b: LocationResult) => {
            // Prioritizar resultados de Yumbo
            const aIsYumbo = a.place_name.toLowerCase().includes('yumbo');
            const bIsYumbo = b.place_name.toLowerCase().includes('yumbo');
            
            if (aIsYumbo && !bIsYumbo) return -1;
            if (!aIsYumbo && bIsYumbo) return 1;
            
            return b.relevance - a.relevance;
          });

        setSuggestions(filteredResults);
        setShowSuggestions(true);
      } else {
        // Fallback: crear resultado genérico para Yumbo
        const fallbackResults = [{
          place_name: `${searchQuery}, Yumbo, Valle del Cauca, Colombia`,
          center: [YUMBO_CENTER.lng, YUMBO_CENTER.lat],
          relevance: 0.5,
          context: []
        }];
        
        setSuggestions(fallbackResults);
        setShowSuggestions(true);
      }
    } catch (err: any) {
      console.error('Error searching locations:', err.message || err);
      
      // Fallback: crear resultado genérico para Yumbo si falla la API
      const fallbackResults = [{
        place_name: `${searchQuery}, Yumbo, Valle del Cauca, Colombia`,
        center: [YUMBO_CENTER.lng, YUMBO_CENTER.lat],
        relevance: 0.5,
        context: []
      }];
      
      setSuggestions(fallbackResults);
      setShowSuggestions(true);
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocation = () => {
    // Verificar si la geolocalización está disponible
    if (!navigator.geolocation) {
      setError('La geolocalización no está disponible en tu navegador');
      // Usar ubicación por defecto de Yumbo
      useYumboFallback();
      return;
    }

    setLoading(true);
    setError(null);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        
        try {
          // Reverse geocoding para obtener la dirección usando OpenStreetMap
          const url = `https://nominatim.openstreetmap.org/reverse?` +
            `lat=${latitude}&` +
            `lon=${longitude}&` +
            `format=json&` +
            `addressdetails=1&` +
            `accept-language=es`;
          
          const response = await fetch(url, {
            headers: {
              'User-Agent': 'GoodImpact-App/1.0'
            }
          });
          
          if (response.ok) {
            const data = await response.json();
            const address = data.display_name || `Ubicación ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
            
            setQuery(address);
            setSelectedLocation({
              place_name: address,
              center: [longitude, latitude],
              relevance: 1
            });
            
            onLocationSelect({
              lat: latitude,
              lng: longitude,
              address: address
            });
            
            setShowSuggestions(false);
          } else {
            // Fallback si falla el reverse geocoding
            const fallbackAddress = `Ubicación personalizada (${latitude.toFixed(4)}, ${longitude.toFixed(4)})`;
            
            setQuery(fallbackAddress);
            setSelectedLocation({
              place_name: fallbackAddress,
              center: [longitude, latitude],
              relevance: 1
            });
            
            onLocationSelect({
              lat: latitude,
              lng: longitude,
              address: fallbackAddress
            });
            
            setShowSuggestions(false);
          }
        } catch (err) {
          console.error('Error getting address:', err);
          // En caso de error, usar la ubicación GPS pero sin descripción
          const fallbackAddress = `Coordenadas GPS (${latitude.toFixed(4)}, ${longitude.toFixed(4)})`;
          
          setQuery(fallbackAddress);
          setSelectedLocation({
            place_name: fallbackAddress,
            center: [longitude, latitude],
            relevance: 1
          });
          
          onLocationSelect({
            lat: latitude,
            lng: longitude,
            address: fallbackAddress
          });
          
          setShowSuggestions(false);
        } finally {
          setLoading(false);
        }
      },
      (error) => {
        let errorMessage = 'No se pudo obtener tu ubicación actual';
        let errorCode = 'UNKNOWN';
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorCode = 'PERMISSION_DENIED';
            errorMessage = '📍 Permiso de ubicación denegado. Haz clic en el ícono de candado junto a la URL para permitir la ubicación. Usando Yumbo por defecto.';
            break;
          case error.POSITION_UNAVAILABLE:
            errorCode = 'POSITION_UNAVAILABLE';
            errorMessage = '🛰️ Ubicación GPS no disponible en este momento. Verifica tu señal. Usando Yumbo por defecto.';
            break;
          case error.TIMEOUT:
            errorCode = 'TIMEOUT';
            errorMessage = '⏱️ El GPS está tardando demasiado. Verifica tu conexión. Usando Yumbo por defecto.';
            break;
          default:
            errorCode = 'UNKNOWN';
            // Verificar si es el error específico de permisos deshabilitados
            if (error.message && error.message.includes('permissions policy')) {
              errorCode = 'PERMISSIONS_POLICY';
              errorMessage = '🔒 Geolocalización deshabilitada por políticas de seguridad del navegador. Usando Yumbo por defecto.';
            } else {
              errorMessage = `⚠️ ${error.message || 'Error desconocido'}. Usando Yumbo por defecto.`;
            }
        }
        
        console.log('📍 LocationSearch - Geolocation error:', {
          errorCode: errorCode,
          errorType: error.code === 1 ? 'PERMISSION_DENIED' : error.code === 2 ? 'POSITION_UNAVAILABLE' : error.code === 3 ? 'TIMEOUT' : 'UNKNOWN',
          originalCode: error.code,
          originalMessage: error.message,
          userFriendlyMessage: errorMessage,
          fallbackLocation: 'Yumbo, Valle del Cauca',
          timestamp: new Date().toISOString()
        });
        
        setError(errorMessage);
        
        // Usar ubicación por defecto de Yumbo como fallback
        useYumboFallback();
        
        setLoading(false);
      },
      {
        enableHighAccuracy: false, // Reducir precisión para mayor compatibilidad
        timeout: 8000, // Reducir timeout
        maximumAge: 300000 // 5 minutos de cache
      }
    );
  };

  const useYumboFallback = () => {
    const yumboAddress = 'Yumbo, Valle del Cauca, Colombia';
    
    setQuery(yumboAddress);
    setSelectedLocation({
      place_name: yumboAddress,
      center: [YUMBO_CENTER.lng, YUMBO_CENTER.lat],
      relevance: 1
    });
    
    onLocationSelect({
      lat: YUMBO_CENTER.lat,
      lng: YUMBO_CENTER.lng,
      address: yumboAddress
    });
    
    setShowSuggestions(false);
  };

  const selectLocation = (location: LocationResult) => {
    setQuery(location.place_name);
    setSelectedLocation(location);
    setShowSuggestions(false);
    setError(null);
    
    onLocationSelect({
      lat: location.center[1],
      lng: location.center[0],
      address: location.place_name
    });
  };

  const isInYumbo = (placeName: string) => {
    return placeName.toLowerCase().includes('yumbo');
  };

  return (
    <div className="relative w-full">
      <div className="flex space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
            placeholder={placeholder}
            className="pl-10 text-base"
          />
          {loading && (
            <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 animate-spin text-blue-600" />
          )}
          {selectedLocation && !loading && (
            <CheckCircle className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-green-600" />
          )}
        </div>
        
        <Button
          type="button"
          variant="outline"
          onClick={getCurrentLocation}
          disabled={loading}
          className="flex items-center space-x-2"
        >
          <Navigation className="w-4 h-4" />
          <span className="hidden sm:inline">Mi ubicación</span>
        </Button>
      </div>

      {error && (
        <div className="mt-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded-md p-2">
          {error}
        </div>
      )}

      {showSuggestions && suggestions.length > 0 && (
        <Card className="absolute top-full left-0 right-0 z-50 mt-1 shadow-xl border-2 border-blue-200">
          <CardContent className="p-2">
            <div className="space-y-1">
              {suggestions.map((location, index) => (
                <div
                  key={index}
                  onClick={() => selectLocation(location)}
                  className="p-3 hover:bg-blue-50 cursor-pointer rounded-md transition-colors border border-transparent hover:border-blue-200"
                >
                  <div className="flex items-start space-x-3">
                    <MapPin className={`w-4 h-4 mt-1 flex-shrink-0 ${
                      isInYumbo(location.place_name) ? 'text-green-600' : 'text-gray-400'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {location.place_name.split(',')[0]}
                        </p>
                        {isInYumbo(location.place_name) && (
                          <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                            ✨ Yumbo
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-gray-600 truncate">
                        {location.place_name}
                      </p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {Math.round(location.relevance * 100)}% coincidencia
                        </Badge>
                        {focusOnYumbo && (
                          <span className="text-xs text-gray-500">
                            📍 {Math.round(
                              Math.sqrt(
                                Math.pow((location.center[1] - YUMBO_CENTER.lat) * 111, 2) +
                                Math.pow((location.center[0] - YUMBO_CENTER.lng) * 111, 2)
                              )
                            )} km del centro
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-3 p-2 bg-blue-50 rounded-md border border-blue-200">
              <p className="text-xs text-blue-800 text-center">
                💡 <strong>Tip:</strong> Los resultados de Yumbo aparecen primero con ✨
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}